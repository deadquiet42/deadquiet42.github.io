#!/usr/bin/env python3
"""MOMO, an expressive silent presence for JeremyOS."""

import ctypes
import json
import math
import os
import random
import struct
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path


WIDTH = 640
HEIGHT = 480
FRAME_STEP = 1.0 / 60.0
BEHAVIOUR_STEP = 1.0 / 120.0
BLACK = (0, 0, 0)
FORM_PALETTE = (
    (0, 255, 236),
    (204, 0, 255),
    (255, 0, 206),
    (33, 255, 37),
    (255, 252, 2),
)
EYE_GRADIENT_STEPS = 12
EYE_GRADIENT_BOTTOM = 0.92
EYE_GRADIENT_PALETTE = tuple(
    tuple(tuple(round(channel * (1.0 - (1.0 - EYE_GRADIENT_BOTTOM) *
                                  shade / EYE_GRADIENT_STEPS))
                for channel in colour)
          for shade in range(EYE_GRADIENT_STEPS + 1))
    for colour in FORM_PALETTE
)

# Developer tuning
BLINK_INTERVAL = (3.0, 8.5)
DOUBLE_BLINK_CHANCE = 0.11
ATTENTION_TRANSITION = (0.075, 0.17)
IDLE_SLEEPY = 48.0
IDLE_ASLEEP = 92.0
SLEEP_CLOSE_TIME = 5.0
VIEWER_NOTICE_CHANCE = 0.045
ASYMMETRY_RANGE = 0.055
STIMULUS_COALESCE_WINDOW = 0.20
STIMULUS_MAX_WINDOW = 0.42
STIMULUS_STALE_AFTER = 2.4
STIMULUS_DECAY = 0.25
ATTENTION_ACCUMULATION = 0.34
IRRITATION_ACCUMULATION = 0.18
IRRITATION_DECAY = 0.035
CURIOSITY_RECOVERY = 0.025
COMFORT_RECOVERY = 0.020
INTEREST_DECAY = 0.014
EXPRESSION_INTENSITY = 0.13
ARKOS_AUDIO_MIX_VOLUME = 128
PLATFORM = os.environ.get("MOMO_PLATFORM", "arkos")
PORTMASTER = PLATFORM == "portmaster"
HANDHELD = PLATFORM in ("arkos", "portmaster")
POWER_POLL_INTERVAL = 0.5
REACTION_DELAY = (0.10, 0.38)
REACTIVE_GAZE_DURATION = (0.95, 1.75)
IDLE_GAZE_DURATION = (1.25, 2.35)
CENTRED_REST_DURATION = (2.8, 6.2)
AUTONOMOUS_REST_DURATION = (3.4, 7.8)
WAKE_LOCK_TIME = 1.95
INTENTION_MINIMUM_LIFETIME = 1.25
CHAOS_INPUT_COUNT = 8
CHAOS_IGNORE_TIME = 3.2
CONTACT_RESPONSE_WINDOW = 4.8
MICRO_BEHAVIOUR_PROBABILITY = 0.16
IDLE_VOCALISATION_PROBABILITY = 0.46
VOCALISATION_PROBABILITY = 0.34
VOCAL_DELAY = (0.32, 0.78)
VOCAL_COOLDOWN = 1.35
AUDIO_RATE = 48000
AUDIO_CHANNELS = 2
MOMO_VOICE_GAIN = 2.35
VOICE_VARIATIONS = 2
VOICE_INTENTS = ("acknowledge", "notice", "question", "pleased", "curious",
                 "startled", "protest", "mutter", "sleepy", "wake",
                 "click", "squeak", "chatter", "residue", "flutter",
                 "idle_breath", "idle_pop", "idle_chime", "idle_ripple")
PHRASE_RECIPES = {
    "phrase_acknowledge": (("click", 0, 0.080), ("acknowledge", 1, 0.0)),
    "phrase_notice": (("residue", 1, 0.100), ("notice", 0, 0.0)),
    "phrase_question": (("click", 0, 0.120), ("question", 1, 0.0)),
    "phrase_pleased": (("click", 1, 0.090), ("pleased", 0, 0.0)),
    "phrase_curious": (("click", 0, 0.120), ("curious", 1, 0.0)),
    "phrase_startled": (("click", 1, 0.055), ("startled", 0, 0.0)),
    "phrase_protest": (("protest", 0, 0.100), ("click", 1, 0.0)),
    "phrase_mutter": (("mutter", 1, 0.110), ("click", 0, 0.0)),
    "phrase_sleepy": (("sleepy", 0, 0.140), ("residue", 1, 0.0)),
    "phrase_wake": (("click", 0, 0.120), ("wake", 1, 0.0)),
}
PHRASE_INTENTS = tuple(PHRASE_RECIPES)
PHRASE_FOR_INTENT = {
    intent: "phrase_" + intent for intent in
    ("acknowledge", "notice", "question", "pleased", "curious", "startled",
     "protest", "mutter", "sleepy", "wake")
}
VOICE_PHRASE_INTERVALS = (3, 2, 4)
VOICE_BANK_VERSION = 4
PITCH_BEND_INTENTS = ("question", "wake")
LILT_NOTE_SYSTEM = {
    "E4": 329.628,
    "G4": 391.995,
    "A4": 440.000,
    "C5": 523.251,
    "D5": 587.330,
    "E5": 659.256,
    "G5": 783.990,
}
PHRASE_NOTES = {
    "phrase_acknowledge": ("A4", "C5"),
    "phrase_notice": ("G4", "A4"),
    "phrase_question": ("G4", "C5"),
    "phrase_pleased": ("C5", "E5"),
    "phrase_curious": ("A4", "C5"),
    "phrase_startled": ("E5", "C5"),
    "phrase_protest": ("G4", "E4"),
    "phrase_mutter": ("E4", "G4"),
    "phrase_sleepy": ("G4", "E4"),
    "phrase_wake": ("G4", "C5"),
}
VOICE_PROFILES = {
    "acknowledge": ("soft_mallet", 0.16, 440.0, 494.0, 0.18, 0.008, 0.075, 0.32, 0.072, 0.07, 0.06, ()),
    "notice": ("hollow_key", 0.18, 392.0, 523.0, 0.18, 0.007, 0.090, 0.34, 0.082, 0.08, 0.07, ()),
    "question": ("hollow_key", 0.31, 392.0, 587.0, 0.20, 0.009, 0.145, 0.32, 0.104, 0.10, 0.08, ()),
    "pleased": ("glass_bell", 0.32, 523.0, 659.0, 0.19, 0.006, 0.150, 0.24, 0.112, 0.11, 0.10, ()),
    "curious": ("hollow_key", 0.25, 440.0, 554.0, 0.18, 0.008, 0.120, 0.31, 0.096, 0.09, 0.08, ()),
    "startled": ("muted_pluck", 0.14, 659.0, 494.0, 0.19, 0.004, 0.052, 0.27, 0.066, 0.05, 0.04, ()),
    "protest": ("velvet_pulse", 0.28, 392.0, 330.0, 0.16, 0.010, 0.125, 0.18, 0.088, 0.06, 0.05, ()),
    "mutter": ("velvet_pulse", 0.32, 349.0, 330.0, 0.14, 0.012, 0.145, 0.18, 0.094, 0.07, 0.07, ()),
    "sleepy": ("soft_mallet", 0.38, 392.0, 330.0, 0.14, 0.018, 0.180, 0.27, 0.118, 0.09, 0.11, ()),
    "wake": ("glass_bell", 0.30, 392.0, 587.0, 0.17, 0.010, 0.145, 0.29, 0.106, 0.09, 0.09, ()),
    "click": ("muted_pluck", 0.065, 493.0, 392.0, 0.20, 0.002, 0.022, 0.25, 0.052, 0.025, 0.025, ()),
    "squeak": ("glass_bell", 0.13, 587.0, 784.0, 0.17, 0.004, 0.055, 0.20, 0.074, 0.05, 0.05, ()),
    "chatter": ("hollow_key", 0.24, 440.0, 523.0, 0.16, 0.006, 0.060, 0.28, 0.092, 0.07, 0.08, (0.0, 0.110)),
    "residue": ("velvet_pulse", 0.24, 392.0, 349.0, 0.13, 0.005, 0.052, 0.18, 0.078, 0.09, 0.09, (0.0, 0.120)),
    "flutter": ("soft_mallet", 0.21, 440.0, 494.0, 0.14, 0.006, 0.056, 0.29, 0.086, 0.07, 0.08, (0.0, 0.105)),
    "idle_breath": ("soft_mallet", 0.42, 440.0, 440.0, 0.085, 0.022, 0.190, 0.27, 0.118, 0.05, 0.12, ()),
    "idle_pop": ("muted_pluck", 0.085, 523.0, 523.0, 0.105, 0.006, 0.030, 0.23, 0.070, 0.04, 0.06, ()),
    "idle_chime": ("glass_bell", 0.30, 523.0, 523.0, 0.085, 0.018, 0.145, 0.24, 0.110, 0.06, 0.11, ()),
    "idle_ripple": ("hollow_key", 0.32, 392.0, 392.0, 0.080, 0.014, 0.090, 0.25, 0.098, 0.07, 0.10, (0.0, 0.155)),
}
VOCAL_FAMILIES = {
    "acknowledge": ("acknowledge", "click", "flutter", "squeak"),
    "notice": ("notice", "click", "residue", "curious"),
    "question": ("question", "flutter", "chatter"),
    "pleased": ("pleased", "squeak", "flutter", "chatter"),
    "curious": ("curious", "residue", "click"),
    "startled": ("startled", "squeak", "click"),
    "protest": ("protest", "mutter", "residue", "click"),
    "mutter": ("mutter", "residue", "click", "chatter"),
    "sleepy": ("sleepy", "mutter", "residue"),
    "wake": ("wake", "flutter", "squeak", "notice"),
    "click": ("click", "flutter"),
    "squeak": ("squeak", "flutter"),
    "chatter": ("chatter", "residue"),
    "residue": ("residue", "flutter"),
    "flutter": ("flutter", "squeak"),
    "idle_breath": ("idle_breath", "idle_chime"),
    "idle_pop": ("idle_pop", "idle_breath"),
    "idle_chime": ("idle_chime", "idle_ripple"),
    "idle_ripple": ("idle_ripple", "idle_breath"),
}


def clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def approach(current, target, speed, elapsed):
    amount = 1.0 - math.exp(-speed * elapsed)
    return current + (target - current) * amount


def smoothstep(value):
    value = clamp(value)
    return value * value * (3.0 - 2.0 * value)


def poly_blep(phase, increment):
    if increment <= 0.0:
        return 0.0
    if phase < increment:
        value = phase / increment
        return value + value - value * value - 1.0
    if phase > 1.0 - increment:
        value = (phase - 1.0) / increment
        return value * value + value + value + 1.0
    return 0.0


def soft_pulse(phase, increment, width=0.38):
    shifted = phase - width
    value = 1.0 if phase < width else -1.0
    if shifted < 0.0:
        shifted += 1.0
    return value + poly_blep(phase, increment) - poly_blep(shifted, increment)


def base_voice(form, phase, increment):
    fundamental = math.sin(phase * math.tau)
    triangle = 1.0 - 4.0 * abs(phase - 0.5)
    if form == "soft_mallet":
        return fundamental * 0.78 + math.sin(phase * math.tau * 2.0) * 0.15 + triangle * 0.07
    if form == "glass_bell":
        return (fundamental * 0.62 + math.sin(phase * math.tau * 3.0) * 0.25 +
                math.sin(phase * math.tau * 5.0) * 0.13)
    if form == "muted_pluck":
        return fundamental * 0.55 + triangle * 0.33 + math.sin(phase * math.tau * 4.0) * 0.12
    if form == "hollow_key":
        return fundamental * 0.74 - math.sin(phase * math.tau * 2.0) * 0.20 + math.sin(phase * math.tau * 3.0) * 0.06
    if form == "velvet_pulse":
        return soft_pulse(phase, increment) * 0.38 + fundamental * 0.62
    raise ValueError("Unknown MOMO base voice: " + str(form))


def render_syllable(intent, variation, sample_rate, note_pitch=None):
    if intent not in VOICE_PROFILES:
        raise ValueError("Unknown MOMO vocal intent: " + str(intent))
    (form, duration, start_pitch, end_pitch, level, attack_time, release_time,
     filter_alpha, delay_time, delay_mix, room_mix, rhythm) = VOICE_PROFILES[intent]
    variation = int(variation) % VOICE_VARIATIONS
    duration *= (0.96, 1.04)[variation]
    pitch_scale = (0.97, 1.03)[variation]
    if note_pitch is not None:
        start_pitch = note_pitch * 0.997
        end_pitch = note_pitch * 1.003
    elif intent not in PITCH_BEND_INTENTS or variation == 0:
        centre_pitch = (start_pitch + end_pitch) * 0.5
        start_pitch = centre_pitch
        end_pitch = centre_pitch
    count = int(duration * sample_rate)
    output = [0.0] * count
    phase = 0.0
    lowpass = 0.0
    for index in range(count):
        position = index / sample_rate
        progress = position / duration
        pitch = (start_pitch + (end_pitch - start_pitch) * smoothstep(progress)) * pitch_scale
        if intent in ("question", "pleased", "curious", "squeak"):
            pitch *= 1.0 + math.sin(position * math.tau * 5.5) * 0.009
        increment = pitch / sample_rate
        voice = base_voice(form, phase, increment)
        phase = (phase + increment) % 1.0
        effective_rhythm = rhythm
        if intent == "click":
            effective_rhythm = (0.0,) if variation == 0 else (0.0, 0.034)
            local_click = min((position - onset for onset in effective_rhythm
                               if position >= onset), default=position)
            click_ring = (math.sin(local_click * math.tau * 840.0) *
                          math.exp(-local_click / 0.009))
            voice = voice * 0.58 + click_ring * 0.42
        if effective_rhythm:
            envelope = 0.0
            for onset in effective_rhythm:
                local = position - onset
                if local >= 0.0:
                    onset_attack = smoothstep(local / attack_time)
                    envelope = max(envelope, onset_attack * math.exp(-local / release_time))
        else:
            attack = smoothstep(position / attack_time)
            envelope = attack * math.exp(-max(0.0, position - attack_time) / release_time)
        lowpass += filter_alpha * (voice - lowpass)
        output[index] = lowpass * envelope * level
    return output, delay_time, delay_mix, room_mix


def voice_events(intent, variation):
    if intent not in PHRASE_RECIPES:
        return ((intent, int(variation) % VOICE_VARIATIONS, 0.0, None),)
    events = []
    position = 0.0
    notes = PHRASE_NOTES[intent]
    for index, (syllable, offset, pause) in enumerate(PHRASE_RECIPES[intent]):
        syllable_variation = (variation + offset) % VOICE_VARIATIONS
        events.append((syllable, syllable_variation, position,
                       LILT_NOTE_SYSTEM[notes[index]]))
        position += VOICE_PROFILES[syllable][1] * (0.96, 1.04)[syllable_variation] + pause
    return tuple(events)


def voice_pcm(intent, variation=0, sample_rate=AUDIO_RATE, gain=MOMO_VOICE_GAIN):
    rendered = []
    dry_length = 0
    delay_time = delay_mix = room_mix = 0.0
    for syllable, syllable_variation, start, note_pitch in voice_events(intent, variation):
        samples, event_delay, event_delay_mix, event_room_mix = render_syllable(
            syllable, syllable_variation, sample_rate, note_pitch)
        start_sample = int(start * sample_rate)
        rendered.append((start_sample, samples))
        dry_length = max(dry_length, start_sample + len(samples))
        delay_time = max(delay_time, event_delay)
        delay_mix = max(delay_mix, event_delay_mix)
        room_mix = max(room_mix, event_room_mix)
    tail = 0.10 + room_mix * 1.6 + delay_mix * 0.8
    dry = [0.0] * (dry_length + int(tail * sample_rate))
    for start_sample, samples in rendered:
        for index, value in enumerate(samples):
            dry[start_sample + index] += value

    delay_size = max(1, int(delay_time * sample_rate))
    room_a_size = max(1, int((0.074 + variation * 0.002) * sample_rate))
    room_b_size = max(1, int((0.088 - variation * 0.002) * sample_rate))
    delay_buffer = [0.0] * delay_size
    room_a = [0.0] * room_a_size
    room_b = [0.0] * room_b_size
    delay_position = room_a_position = room_b_position = 0
    previous_mix = highpass = 0.0
    stereo = []
    pan = (-0.055, 0.055)[int(variation) % VOICE_VARIATIONS]
    fade_in_frames = max(1, int(0.004 * sample_rate))
    fade_out_frames = max(1, int(0.030 * sample_rate))
    for frame_index, value in enumerate(dry):
        highpass = value - previous_mix + 0.9844 * highpass
        previous_mix = value
        delayed = delay_buffer[delay_position]
        delay_buffer[delay_position] = highpass + delayed * 0.15
        delay_position = (delay_position + 1) % delay_size
        reflected_a = room_a[room_a_position]
        reflected_b = room_b[room_b_position]
        room_input = highpass + delayed * delay_mix
        room_a[room_a_position] = room_input + reflected_a * 0.48
        room_b[room_b_position] = room_input + reflected_b * 0.445
        room_a_position = (room_a_position + 1) % room_a_size
        room_b_position = (room_b_position + 1) % room_b_size
        left = highpass + delayed * delay_mix * 0.92 + reflected_a * room_mix
        right = highpass + delayed * delay_mix * 1.08 + reflected_b * room_mix
        left = math.tanh(left * 0.92) * gain
        right = math.tanh(right * 0.92) * gain
        final_envelope = (smoothstep(frame_index / fade_in_frames) *
                          smoothstep((len(dry) - 1 - frame_index) / fade_out_frames))
        left *= final_envelope
        right *= final_envelope
        left *= 1.0 - max(0.0, pan) * 0.18
        right *= 1.0 + min(0.0, pan) * 0.18
        stereo.extend((int(clamp(left, -0.92, 0.92) * 32767),
                       int(clamp(right, -0.92, 0.92) * 32767)))
    if stereo:
        stereo[-2:] = (0, 0)
    return struct.pack("<{}h".format(len(stereo)), *stereo)


def compose_voice_phrase(intent, variation, voice_buffers=None,
                         sample_rate=AUDIO_RATE, gain=MOMO_VOICE_GAIN):
    return voice_pcm(intent, variation, sample_rate, gain)


def voice_bank_path(intent, variation):
    return Path(__file__).with_name("audio") / (intent + "_" + str(variation) + ".pcm")


def load_voice_bank():
    buffers = {}
    directory = Path(__file__).with_name("audio")
    try:
        manifest = json.loads((directory / "manifest.json").read_text(encoding="utf8"))
        bank_is_current = manifest.get("version") == VOICE_BANK_VERSION
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        bank_is_current = False
    for intent in VOICE_INTENTS + PHRASE_INTENTS:
        for variation in range(VOICE_VARIATIONS):
            path = voice_bank_path(intent, variation)
            buffers[(intent, variation)] = (path.read_bytes() if bank_is_current and path.exists() else
                                             voice_pcm(intent, variation))
    return buffers


def voice_signature(intent):
    return intent if intent in PHRASE_RECIPES else VOICE_PROFILES[intent][0]


@dataclass
class EyeGeometry:
    left_x: float
    right_x: float
    left_y: float
    right_y: float
    left_width: float
    right_width: float
    left_height: float
    right_height: float


def power_input_state(root="/sys/class/power_supply"):
    """Return external power state when the kernel exposes a trustworthy source."""
    try:
        supplies = tuple(Path(root).iterdir())
    except OSError:
        return None
    external = []
    battery_states = []
    for supply in supplies:
        try:
            kind = (supply / "type").read_text(encoding="ascii").strip().lower()
        except OSError:
            continue
        if kind == "battery":
            try:
                status = (supply / "status").read_text(encoding="ascii").strip().lower()
            except OSError:
                continue
            if status in ("charging", "full"):
                battery_states.append(True)
            elif status == "discharging":
                battery_states.append(False)
        elif kind in ("mains", "usb", "usb_cdp", "usb_dcp", "usb_pd", "usb_type_c"):
            try:
                online = (supply / "online").read_text(encoding="ascii").strip()
            except OSError:
                continue
            if online in ("0", "1"):
                external.append(online == "1")
    if external:
        return any(external)
    if battery_states:
        return any(battery_states)
    return None


class PowerMonitor:
    def __init__(self, root="/sys/class/power_supply"):
        self.root = root
        self.next_poll = 0.0
        self.candidate = None
        self.candidate_count = 0
        self.confirmed = None

    def poll(self, now):
        if now < self.next_poll:
            return False
        self.next_poll = now + POWER_POLL_INTERVAL
        state = power_input_state(self.root)
        if state is None:
            self.candidate = None
            self.candidate_count = 0
            return False
        if state != self.candidate:
            self.candidate = state
            self.candidate_count = 1
        else:
            self.candidate_count += 1
        if self.candidate_count < 2 or state == self.confirmed:
            return False
        previously_unplugged = self.confirmed is False
        self.confirmed = state
        return previously_unplugged and state


class Momo:
    def __init__(self, profile, seed=None):
        self.profile = Path(profile)
        self.random = random.Random(seed)
        self.colour_index = self.load_colour()
        self.requested_colour_index = self.colour_index
        self.colour_transition_count = 0
        self.elapsed = 0.0
        self.idle = 0.0
        self.stimulation = 0.0
        self.irritation = 0.0
        self.curiosity = 0.62
        self.comfort = 0.72
        self.interest_in_user = 0.45
        self.last_stimulus = -10.0
        self.stimulus_started = -10.0
        self.stimulus_due = 0.0
        self.stimulus_x = 0.0
        self.stimulus_y = 0.0
        self.stimulus_weight = 0.0
        self.stimulus_strength = 0.0
        self.stimulus_count = 0
        self.stimulus_kinds = {}
        self.recent_directions = []
        self.recent_idle_behaviours = []
        self.mood = "waking"
        self.intention = "waking"
        self.expression = "calm"
        self.reactive_expression = False
        self.expression_side = self.random.choice((-1, 1))
        self.expression_until = 0.0
        self.fixation_until = 2.2
        self.decision_due = 2.2
        self.reaction_lock_until = WAKE_LOCK_TIME
        self.ignore_until = 0.0
        self.reaction_count = 0
        self.wake_count = 1
        self.attention_x = 0.0
        self.attention_y = 0.0
        self.target_x = 0.0
        self.target_y = 0.0
        self.attention_return_due = 0.0
        self.shift_speed = 7.0
        self.correction_due = 0.0
        self.correction_pending = False
        self.openness = 0.0
        self.target_openness = 0.0
        self.blink_phase = "startup"
        self.blink_kind = "startup"
        self.blink_time = 0.0
        self.blink_start_openness = 1.0
        self.blink_rest_openness = 1.0
        self.next_blink = self.random.uniform(*BLINK_INTERVAL)
        self.double_blink_pending = False
        self.sleep_progress = 0.0
        self.sleep_start_openness = 1.0
        self.wake_time = 0.0
        self.wake_left_first = True
        self.rouse_time = 0.0
        self.rouse_start_openness = 1.0
        self.asymmetry = 0.0
        self.pending_reaction = None
        self.pending_voice = None
        self.voice_ready = None
        self.voice_cooldown_until = 0.0
        self.voice_serial = 0
        self.voice_family_cursor = {}
        self.voices_since_phrase = 0
        self.voice_phrase_interval_index = 0
        self.last_voice_form = None
        self.voice_repeat_count = 0
        self.contact_waiting = False
        self.contact_deadline = 0.0
        self.contact_answered = False
        self.sleepy_voice_used = False
        self.anticipation = 0.0
        self.last_interactions = []
        self.last_side_poke_expression = None
        self.last_side_variant = None
        self.side_variant = None
        self.side_reaction_side = 0
        self.side_reaction_started = 0.0
        self.side_release_used = False
        self.pose_width = 1.0
        self.pose_height = 1.0
        self.pose_spacing = 226.0
        self.pose_vertical = 0.0
        self.pose_left_scale = 1.0
        self.pose_right_scale = 1.0
        self.pose_left_offset = 0.0
        self.pose_right_offset = 0.0
        self.pose_left_width = 1.0
        self.pose_right_width = 1.0
        self.idle_followup = None
        self.wink_side = None
        self.wink_phase = "open"
        self.wink_time = 0.0
        self.left_wink = 1.0
        self.right_wink = 1.0

    @property
    def colour(self):
        return FORM_PALETTE[self.colour_index]

    def load_colour(self):
        try:
            value = json.loads((self.profile / "colour.json").read_text(encoding="utf8"))
            index = int(value["colour_index"])
            return index % len(FORM_PALETTE)
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return 0

    def save_colour(self):
        try:
            self.profile.mkdir(parents=True, exist_ok=True)
            handle, temporary = tempfile.mkstemp(prefix="momo_", suffix=".tmp",
                                                 dir=str(self.profile))
            with os.fdopen(handle, "w", encoding="utf8") as stream:
                json.dump({"colour_index": self.colour_index}, stream)
                stream.write("\n")
            os.replace(temporary, self.profile / "colour.json")
        except OSError:
            pass

    def cycle_colour(self):
        self.register_activity(0.35)
        self.requested_colour_index = ((self.requested_colour_index + 1) %
                                       len(FORM_PALETTE))
        if self.mood not in ("waking", "rousing") and self.blink_phase == "open":
            self.colour_transition_count += 1
            self.begin_blink("colour")

    def begin_blink(self, kind="normal"):
        if self.blink_phase != "open" or self.wink_phase != "open":
            return
        self.blink_phase = "closing"
        self.blink_time = 0.0
        self.blink_kind = kind
        self.blink_start_openness = clamp(self.openness)
        self.blink_rest_openness = 0.62 if self.mood == "sleepy" else 1.0
        self.asymmetry = self.random.uniform(-ASYMMETRY_RANGE, ASYMMETRY_RANGE)
        if kind == "normal":
            self.double_blink_pending = self.random.random() < DOUBLE_BLINK_CHANCE

    def register_activity(self, strength=1.0):
        was_sleeping = self.mood in ("asleep", "sleepy")
        was_fully_asleep = self.mood == "asleep" and self.openness <= 0.05
        repeated = self.elapsed - self.last_stimulus < 0.62
        self.last_stimulus = self.elapsed
        self.idle = 0.0
        self.stimulation = clamp(self.stimulation + strength * ATTENTION_ACCUMULATION)
        if repeated:
            self.irritation = clamp(self.irritation + strength * IRRITATION_ACCUMULATION)
            self.comfort = clamp(self.comfort - strength * 0.055)
        else:
            self.irritation = clamp(self.irritation - 0.08)
            self.curiosity = clamp(self.curiosity + strength * 0.08)
        if was_fully_asleep:
            self.start_wake()
        elif was_sleeping:
            self.start_rouse()
        return was_sleeping

    def receive_stimulus(self, kind, x=0.0, y=0.0, strength=0.7):
        self.register_activity(strength)
        self.idle_followup = None
        if self.stimulus_count == 0:
            self.stimulus_started = self.elapsed
            self.stimulus_due = self.elapsed + STIMULUS_COALESCE_WINDOW
        else:
            self.stimulus_due = min(self.stimulus_started + STIMULUS_MAX_WINDOW,
                                    self.elapsed + STIMULUS_COALESCE_WINDOW)
        magnitude = math.hypot(x, y)
        if magnitude:
            x, y = x / magnitude, y / magnitude
        self.stimulus_x += x * strength
        self.stimulus_y += y * strength
        self.stimulus_weight += strength
        self.stimulus_strength = clamp(self.stimulus_strength + strength * 0.24)
        self.stimulus_count += 1
        self.stimulus_kinds[kind] = self.stimulus_kinds.get(kind, 0) + 1
        if self.contact_waiting and self.elapsed <= self.contact_deadline:
            self.contact_answered = True
            self.interest_in_user = clamp(self.interest_in_user + 0.24)
            self.comfort = clamp(self.comfort + 0.10)

    def clear_stimulus(self):
        self.stimulus_x = 0.0
        self.stimulus_y = 0.0
        self.stimulus_weight = 0.0
        self.stimulus_strength = 0.0
        self.stimulus_count = 0
        self.stimulus_kinds.clear()
        self.stimulus_due = 0.0

    def schedule_voice(self, intent, delay=None, probability=VOCALISATION_PROBABILITY,
                       priority=0):
        if intent not in VOICE_INTENTS or self.random.random() > probability:
            return
        if self.elapsed < self.voice_cooldown_until or self.voice_ready is not None:
            return
        if self.pending_voice is not None and priority <= self.pending_voice["priority"]:
            return
        due = self.elapsed + (delay if delay is not None else
                              self.random.uniform(*VOCAL_DELAY))
        family = tuple(dict.fromkeys(VOCAL_FAMILIES[intent]))
        cursor = self.voice_family_cursor.get(intent, 0)
        actual_intent = family[cursor % len(family)]
        self.voice_family_cursor[intent] = cursor + 1
        if intent in PHRASE_FOR_INTENT:
            self.voices_since_phrase += 1
            phrase_interval = VOICE_PHRASE_INTERVALS[self.voice_phrase_interval_index]
            strongly_expressive = (intent in ("question", "pleased", "protest", "wake")
                                   and (self.stimulation > 0.62 or self.irritation > 0.48))
            if (self.voices_since_phrase >= phrase_interval or
                    (strongly_expressive and self.voices_since_phrase >= 2)):
                actual_intent = PHRASE_FOR_INTENT[intent]
                self.voices_since_phrase = 0
                self.voice_phrase_interval_index = (
                    (self.voice_phrase_interval_index + 1) % len(VOICE_PHRASE_INTERVALS))
        signature = voice_signature(actual_intent)
        if signature == self.last_voice_form and self.voice_repeat_count >= 2:
            alternatives = [item for item in family
                            if voice_signature(item) != self.last_voice_form]
            if alternatives:
                actual_intent = alternatives[cursor % len(alternatives)]
                signature = voice_signature(actual_intent)
        if signature == self.last_voice_form:
            self.voice_repeat_count += 1
        else:
            self.last_voice_form = signature
            self.voice_repeat_count = 1
        candidate = {"intent": actual_intent, "source_intent": intent,
                     "due": due, "priority": priority}
        self.pending_voice = candidate

    def update_voice(self):
        if self.pending_voice and self.elapsed >= self.pending_voice["due"]:
            if self.elapsed >= self.voice_cooldown_until and self.voice_ready is None:
                intent = self.pending_voice["intent"]
                self.voice_ready = (intent, self.voice_serial % VOICE_VARIATIONS)
                self.voice_serial += 1
                self.voice_cooldown_until = self.elapsed + VOCAL_COOLDOWN
            self.pending_voice = None

    def take_voice(self):
        voice = self.voice_ready
        self.voice_ready = None
        return voice

    def commit_reaction(self, expression, target=None, hold=2.6, blink=False,
                        voice=None, voice_probability=VOCALISATION_PROBABILITY,
                        voice_priority=0, voice_lag=(0.28, 0.62),
                        side_variant=None, side=0):
        delay = self.random.uniform(*REACTION_DELAY)
        self.pending_reaction = {
            "due": self.elapsed + delay,
            "expression": expression,
            "target": target,
            "hold": max(INTENTION_MINIMUM_LIFETIME, hold),
            "blink": blink,
            "side_variant": side_variant,
            "side": side,
        }
        self.intention = "reacting"
        self.reaction_count += 1
        self.reaction_lock_until = self.elapsed + delay + self.pending_reaction["hold"]
        self.fixation_until = self.reaction_lock_until
        self.decision_due = (self.reaction_lock_until +
                             self.random.uniform(*AUTONOMOUS_REST_DURATION))
        self.idle_followup = None
        if voice:
            self.schedule_voice(voice, delay + self.random.uniform(*voice_lag),
                                voice_probability, voice_priority)

    def consume_stimulus(self):
        if not self.stimulus_count:
            return
        if self.elapsed - self.last_stimulus > STIMULUS_STALE_AFTER:
            self.clear_stimulus()
            return
        count = self.stimulus_count
        kinds = dict(self.stimulus_kinds)
        weight = max(0.001, self.stimulus_weight)
        x = clamp(self.stimulus_x / weight, -1.0, 1.0)
        y = clamp(self.stimulus_y / weight, -1.0, 1.0)
        strength = self.stimulus_strength
        self.clear_stimulus()

        if self.elapsed < self.ignore_until:
            return
        target = (x, y) if abs(x) + abs(y) > 0.08 else (0.0, 0.0)
        answered = self.contact_answered
        self.contact_waiting = False
        self.contact_answered = False

        if count >= CHAOS_INPUT_COUNT or self.irritation > 0.76 or strength > 0.94:
            away = (-x * 0.55, -y * 0.35) if target != (0.0, 0.0) else (0.0, 0.0)
            self.curiosity = clamp(self.curiosity - 0.28)
            self.comfort = clamp(self.comfort - 0.20)
            self.ignore_until = self.elapsed + CHAOS_IGNORE_TIME
            self.commit_reaction("irritated", away, 4.2, blink=count < 12,
                                 voice="protest", voice_probability=0.72,
                                 voice_priority=3)
        elif count >= 4 or self.irritation > 0.50:
            self.curiosity = clamp(self.curiosity - 0.12)
            self.commit_reaction("suspicious", target, 3.8,
                                 voice="mutter", voice_probability=0.48,
                                 voice_priority=2)
        elif answered:
            self.commit_reaction("delighted", (0.0, -0.12), 3.0,
                                 voice="pleased", voice_probability=0.68,
                                 voice_priority=2)
        elif kinds.get("call"):
            self.interest_in_user = clamp(self.interest_in_user + 0.14)
            self.commit_reaction("listening", (0.0, 0.0),
                                 self.random.uniform(3.0, 3.6),
                                 voice="question", voice_probability=0.72,
                                 voice_priority=2)
        elif any(kinds.get(kind) for kind in
                 ("edge_left", "edge_right", "flinch", "peek")):
            left = bool(kinds.get("edge_left") or kinds.get("flinch"))
            right = bool(kinds.get("edge_right") or kinds.get("peek"))
            strong = bool(kinds.get("flinch") or kinds.get("peek"))
            both = left and right
            if both:
                expression = "suspicious"
            elif strong:
                expression = "surprised"
            elif self.irritation > 0.28:
                expression = "suspicious"
            else:
                expression = ("suspicious" if self.last_side_poke_expression == "curious"
                              else "curious")
            self.last_side_poke_expression = expression
            if both:
                toward = (0.0, -0.04)
                variant = None
                side = 0
            else:
                toward = (x * 0.72, self.random.uniform(-0.12, 0.08))
                side = -1 if left else 1
                variants = ("glance", "linger", "blink")
                available = [item for item in variants if item != self.last_side_variant]
                if self.irritation > 0.28 and "glance" in available:
                    variant = "glance"
                elif self.comfort > 0.70 and "linger" in available:
                    variant = "linger"
                else:
                    variant = self.random.choice(available)
                self.last_side_variant = variant
            self.commit_reaction(expression, toward,
                                 self.random.uniform(1.8, 2.4),
                                 blink=variant == "blink",
                                 voice="startled" if strong else "click",
                                 voice_probability=0.48 if strong else 0.42,
                                 voice_priority=1,
                                 voice_lag=(0.08, 0.22),
                                 side_variant=variant, side=side)
        elif strength > 0.62:
            self.commit_reaction("surprised", target, 2.0,
                                 voice="startled", voice_probability=0.44,
                                 voice_priority=1)
        elif kinds.get("soothe") or kinds.get("watch"):
            self.comfort = clamp(self.comfort + 0.12)
            self.commit_reaction("attentive", target, 3.0,
                                 voice="acknowledge", voice_probability=0.28)
        elif kinds.get("play"):
            self.curiosity = clamp(self.curiosity + 0.12)
            self.commit_reaction("delighted", target, 2.8,
                                 voice="pleased", voice_probability=0.40)
        else:
            expression = "curious" if self.curiosity > 0.38 else "suspicious"
            self.commit_reaction(expression, target, 3.1,
                                 voice="curious", voice_probability=0.34)

    def stimulus(self, x, y, strength=1.0):
        self.receive_stimulus("direction", x, y, strength)

    def interact(self, kind):
        self.last_interactions.append(kind)
        self.last_interactions = self.last_interactions[-4:]
        spatial = {
            "surprise": (0.0, -1.0, 0.72),
            "soothe": (0.0, 1.0, 0.42),
            "tease": (-1.0, 0.0, 0.58),
            "greet": (1.0, 0.0, 0.52),
            "edge_left": (-1.0, 0.0, 0.62),
            "edge_right": (1.0, 0.0, 0.62),
            "flinch": (-1.0, 0.0, 0.88),
            "peek": (1.0, 0.0, 0.88),
            "lean_in": (0.0, -0.5, 0.50),
            "withdraw": (0.0, 0.7, 0.66),
        }
        if kind == "startle":
            self.receive_stimulus("call", 0.0, 0.0, 0.66)
        elif kind in spatial:
            x, y, strength = spatial[kind]
            self.receive_stimulus(kind, x, y, strength)
        else:
            self.receive_stimulus(kind, 0.0, 0.0, 0.52)

    def release_shoulder(self, button):
        side = -1 if button in (4, 6) else 1
        if (self.side_variant == "linger" and self.side_reaction_side == side and
                not self.side_release_used and self.attention_return_due > self.elapsed):
            self.attention_return_due += 0.18
            self.side_release_used = True

    def power_connected(self):
        self.register_activity(0.75)
        self.comfort = clamp(self.comfort + 0.18)
        self.curiosity = clamp(self.curiosity + 0.12)
        self.commit_reaction("excited", (0.0, -0.16), 4.2, blink=True,
                             voice="pleased", voice_probability=1.0,
                             voice_priority=3)
        if self.mood == "waking":
            self.pending_reaction["due"] = self.elapsed + 1.75
            if self.pending_voice:
                self.pending_voice["due"] = max(self.pending_voice["due"],
                                                 self.elapsed + 2.0)

    def begin_wink(self, side=None):
        if self.wink_phase != "open" or self.blink_phase != "open":
            return
        self.wink_side = side or self.random.choice(("left", "right"))
        self.wink_phase = "closing"
        self.wink_time = 0.0

    def update_wink(self, elapsed):
        if self.wink_phase == "open":
            return
        self.wink_time += elapsed
        affected = "left_wink" if self.wink_side == "left" else "right_wink"
        if self.wink_phase == "closing":
            setattr(self, affected, 1.0 - smoothstep(self.wink_time / 0.11))
            if self.wink_time >= 0.11:
                setattr(self, affected, 0.0)
                self.wink_phase = "closed"
                self.wink_time = 0.0
        elif self.wink_phase == "closed":
            if self.wink_time >= 0.075:
                self.wink_phase = "opening"
                self.wink_time = 0.0
        elif self.wink_phase == "opening":
            setattr(self, affected, smoothstep(self.wink_time / 0.19))
            if self.wink_time >= 0.19:
                self.left_wink = 1.0
                self.right_wink = 1.0
                self.wink_phase = "open"
                self.wink_side = None

    def apply_pending_reaction(self):
        reaction = self.pending_reaction
        if not reaction or self.elapsed < reaction["due"]:
            return
        self.pending_reaction = None
        self.anticipation = 0.0
        self.expression = reaction["expression"]
        self.reactive_expression = True
        self.side_variant = reaction["side_variant"]
        self.side_reaction_side = reaction["side"]
        self.side_reaction_started = self.elapsed
        self.side_release_used = False
        if self.expression == "curious":
            self.expression_side = self.random.choice((-1, 1))
        self.expression_until = self.elapsed + reaction["hold"]
        target = reaction["target"]
        if target is not None:
            self.set_attention(*target, reactive=True)
            self.fixation_until = self.expression_until
            if self.side_variant == "glance":
                self.attention_return_due = self.elapsed + self.random.uniform(0.95, 1.15)
            elif self.side_variant == "linger":
                self.attention_return_due = self.elapsed + self.random.uniform(1.65, 2.05)
        if reaction["blink"] and self.blink_phase == "open":
            self.begin_blink()

    def apply_idle_followup(self):
        reaction = self.idle_followup
        if (not reaction or self.pending_reaction or self.stimulus_count or
                self.elapsed < reaction["due"]):
            return
        self.idle_followup = None
        self.expression = reaction["expression"]
        self.reactive_expression = False
        if self.expression == "curious":
            self.expression_side = self.random.choice((-1, 1))
        self.expression_until = self.elapsed + reaction["hold"]
        self.set_attention(*reaction["target"], reactive=True)
        self.fixation_until = self.expression_until
        self.decision_due = (self.expression_until +
                             self.random.uniform(*AUTONOMOUS_REST_DURATION))

    def set_attention(self, x, y, reactive=False):
        self.target_x = clamp(x, -1.0, 1.0)
        self.target_y = clamp(y, -1.0, 1.0)
        self.shift_speed = 13.0 if reactive else self.random.uniform(7.0, 11.0)
        displaced = abs(self.target_x) > 0.01 or abs(self.target_y) > 0.01
        self.correction_pending = displaced
        if displaced:
            self.expression_side = self.random.choice((-1, 1))
            self.correction_due = self.elapsed + self.random.uniform(0.18, 0.34)
            duration = REACTIVE_GAZE_DURATION if reactive else IDLE_GAZE_DURATION
            self.attention_return_due = self.elapsed + self.random.uniform(*duration)
            self.fixation_until = (self.attention_return_due +
                                   self.random.uniform(*CENTRED_REST_DURATION))
        else:
            self.attention_return_due = 0.0
            self.fixation_until = self.elapsed + self.random.uniform(*CENTRED_REST_DURATION)

    def return_attention_to_rest(self):
        self.target_x = 0.0
        self.target_y = 0.0
        self.attention_return_due = 0.0
        self.correction_pending = False
        self.shift_speed = 5.2 if self.side_variant == "linger" else 6.5
        self.side_variant = None
        self.side_reaction_side = 0

    def start_wake(self):
        if self.mood == "waking":
            return
        self.mood = "waking"
        self.intention = "waking"
        self.wake_count += 1
        self.expression = "attentive"
        self.expression_until = self.elapsed + 1.9
        self.wake_time = 0.0
        self.wake_left_first = self.random.random() < 0.5
        self.sleep_progress = 0.0
        self.blink_phase = "startup"
        self.blink_kind = "startup"
        self.pending_reaction = None
        self.idle_followup = None
        self.pending_voice = None
        self.reaction_lock_until = self.elapsed + WAKE_LOCK_TIME

    def start_rouse(self):
        if self.mood == "rousing":
            return
        self.mood = "rousing"
        self.intention = "rousing"
        self.expression = "attentive"
        self.expression_until = self.elapsed + 1.1
        self.rouse_time = 0.0
        self.rouse_start_openness = max(0.08, self.openness)
        self.sleep_progress = 0.0
        self.blink_phase = "open"
        self.blink_kind = "normal"
        self.double_blink_pending = False
        self.pending_reaction = None
        self.idle_followup = None
        self.pending_voice = None
        self.return_attention_to_rest()
        self.reaction_lock_until = self.elapsed + 1.05
        self.schedule_voice("idle_breath", delay=0.30, probability=0.42)

    def initiate_contact(self):
        self.contact_waiting = True
        self.intention = "communicating"
        self.contact_answered = False
        self.contact_deadline = self.elapsed + CONTACT_RESPONSE_WINDOW
        self.expression = "attentive"
        self.expression_until = self.contact_deadline
        self.set_attention(0.0, 0.0)
        self.reaction_lock_until = self.elapsed + 1.2
        self.decision_due = self.contact_deadline + self.random.uniform(3.0, 6.0)
        self.schedule_voice("question", delay=self.random.uniform(0.62, 0.94),
                            probability=0.78, priority=1)

    def update_contact(self):
        if not self.contact_waiting or self.elapsed < self.contact_deadline:
            return
        self.contact_waiting = False
        self.contact_answered = False
        self.expression = "calm"
        self.expression_until = self.elapsed
        if self.random.random() < MICRO_BEHAVIOUR_PROBABILITY:
            self.begin_blink()

    def update_intention(self):
        if self.mood == "waking":
            self.intention = "waking"
        elif self.mood == "rousing":
            self.intention = "rousing"
        elif self.mood == "asleep":
            self.intention = "sleeping"
        elif self.contact_waiting:
            self.intention = "communicating"
        elif self.pending_reaction or self.elapsed < self.reaction_lock_until:
            self.intention = "reacting"
        elif (self.expression != "calm" or abs(self.attention_x) > 0.03 or
              abs(self.attention_y) > 0.03 or self.blink_phase != "open"):
            self.intention = "settling"
        else:
            self.intention = "idle"

    def choose_attention(self):
        if self.random.random() < VIEWER_NOTICE_CHANCE and self.idle < IDLE_SLEEPY:
            self.initiate_contact()
            return
        directions = [(-1.0, -0.25), (1.0, -0.2), (-0.7, 0.55),
                      (0.72, 0.5), (0.0, -0.8), (0.0, 0.65),
                      (-1.0, 0.05), (1.0, 0.08), (0.0, 0.0)]
        available = [item for item in directions if item not in self.recent_directions[-2:]]
        direction = self.random.choice(available or directions)
        self.recent_directions.append(direction)
        self.recent_directions = self.recent_directions[-4:]
        if self.irritation > 0.58:
            self.set_attention(*direction)
            self.expression = "irritated"
            behaviour = "irritated"
        else:
            behaviours = ("curious_wink", "edge", "inspect", "double_take",
                          "delighted", "surprised", "slow_look", "quiet", "quiet")
            available_behaviours = [item for item in behaviours
                                    if item not in self.recent_idle_behaviours[-2:]]
            behaviour = self.random.choice(available_behaviours or behaviours)
            self.recent_idle_behaviours.append(behaviour)
            self.recent_idle_behaviours = self.recent_idle_behaviours[-4:]
        if behaviour == "curious_wink":
            self.set_attention(*direction)
            self.expression = "curious"
            self.begin_wink()
            self.fixation_until += self.random.uniform(1.0, 2.2)
        elif behaviour == "edge":
            edge = self.random.choice((-1.0, 1.0))
            self.set_attention(edge, self.random.uniform(-0.32, 0.22))
            self.expression = "curious"
            self.fixation_until += self.random.uniform(1.8, 3.4)
        elif behaviour == "inspect":
            self.set_attention(0.0, self.random.uniform(-0.1, 0.18))
            self.expression = "suspicious"
            self.fixation_until += self.random.uniform(2.0, 4.0)
        elif behaviour == "double_take":
            first = self.random.choice(((-0.72, -0.22), (0.72, -0.22)))
            second = (-first[0] * 0.7, first[1] + 0.1)
            self.set_attention(*first)
            self.expression = "surprised"
            self.idle_followup = {
                "due": self.attention_return_due + self.random.uniform(0.45, 0.75),
                "expression": "curious",
                "target": second,
                "hold": self.random.uniform(2.4, 4.2),
            }
        elif behaviour == "delighted" and self.stimulation > 0.22:
            self.set_attention(*direction)
            self.expression = "delighted"
        elif behaviour == "surprised":
            self.set_attention(*direction)
            self.expression = "surprised"
        elif behaviour == "slow_look":
            self.set_attention(direction[0] * 0.5, -0.62)
            self.shift_speed = self.random.uniform(2.4, 3.2)
            self.expression = "curious"
            self.fixation_until += self.random.uniform(3.0, 5.0)
        else:
            self.set_attention(0.0, 0.0)
            self.expression = "calm"
        self.expression_until = self.fixation_until
        self.decision_due = (max(self.expression_until, self.attention_return_due) +
                             self.random.uniform(*AUTONOMOUS_REST_DURATION))
        idle_voices = {
            "quiet": "idle_breath",
            "slow_look": "idle_chime",
            "inspect": "idle_ripple",
            "curious_wink": "idle_pop",
            "edge": "idle_pop",
            "double_take": "idle_ripple",
            "delighted": "idle_chime",
            "surprised": "idle_pop",
        }
        if behaviour in idle_voices:
            self.schedule_voice(idle_voices[behaviour],
                                delay=self.random.uniform(0.36, 0.82),
                                probability=IDLE_VOCALISATION_PROBABILITY)

    def expression_targets(self):
        emphasis = 1.0 + (EXPRESSION_INTENSITY if self.reactive_expression else 0.0)
        targets = [1.0, 1.0, 226.0, 0.0, 1.0, 1.0, 0.0, 0.0,
                   1.0, 1.0]
        if self.expression == "curious":
            targets[4], targets[5] = 1.07, 0.99
            targets[6], targets[7] = -4.0 * emphasis, 1.0
            targets[8], targets[9] = 0.98, 1.01
            if self.expression_side < 0:
                targets[4], targets[5] = targets[5], targets[4]
                targets[6], targets[7] = targets[7], targets[6]
                targets[8], targets[9] = targets[9], targets[8]
        elif self.expression == "delighted":
            targets[0], targets[1], targets[3] = (1.0 + 0.07 * emphasis,
                                                     1.0 + 0.15 * emphasis,
                                                     -10.0 * emphasis)
        elif self.expression == "excited":
            targets[0], targets[1], targets[2], targets[3] = (1.08, 1.30, 238.0, -12.0)
        elif self.expression == "suspicious":
            targets[1], targets[2] = max(0.44, 1.0 - 0.44 * emphasis), 214.0
        elif self.expression == "irritated":
            targets[1], targets[2] = max(0.40, 1.0 - 0.53 * emphasis), 216.0
            targets[8], targets[9] = 1.04, 1.04
        elif self.expression == "surprised":
            targets[0], targets[1] = 0.93, 1.0 + 0.27 * emphasis
            targets[8], targets[9] = 0.96, 0.96
        elif self.expression == "attentive":
            targets[1] = 1.0 + 0.12 * emphasis
        elif self.expression == "listening":
            targets[1], targets[2] = 1.0 + 0.12 * emphasis, 208.0
        elif self.expression == "sleepy":
            targets[1] = 0.68
        if self.side_reaction_side and self.side_variant:
            age = self.elapsed - self.side_reaction_started
            first = 4 if self.side_reaction_side < 0 else 5
            second = 5 if self.side_reaction_side < 0 else 4
            if 0.0 <= age < 0.17:
                targets[first] *= 0.88
            if 0.08 <= age < 0.29:
                targets[second] *= 0.94
        return targets

    def update_expression_pose(self, elapsed):
        targets = self.expression_targets()
        speed = 13.0 if self.expression == "surprised" else 5.8
        self.pose_width = approach(self.pose_width, targets[0], speed, elapsed)
        self.pose_height = approach(self.pose_height, targets[1], speed, elapsed)
        self.pose_spacing = approach(self.pose_spacing, targets[2], speed, elapsed)
        self.pose_vertical = approach(self.pose_vertical, targets[3], speed, elapsed)
        self.pose_left_scale = approach(self.pose_left_scale, targets[4], speed, elapsed)
        self.pose_right_scale = approach(self.pose_right_scale, targets[5], speed, elapsed)
        self.pose_left_offset = approach(self.pose_left_offset, targets[6], speed, elapsed)
        self.pose_right_offset = approach(self.pose_right_offset, targets[7], speed, elapsed)
        self.pose_left_width = approach(self.pose_left_width, targets[8], speed, elapsed)
        self.pose_right_width = approach(self.pose_right_width, targets[9], speed, elapsed)

    def update_startup(self, elapsed):
        self.wake_time += elapsed
        if self.wake_time < 0.28:
            self.openness = 0.0
        elif self.wake_time < 0.62:
            self.openness = 0.05
        elif self.wake_time < 0.92:
            self.openness = 0.32
        elif self.wake_time < 1.34:
            self.openness = approach(self.openness, 0.88, 7.0, elapsed)
        else:
            self.openness = approach(self.openness, 1.0, 8.0, elapsed)
        if self.wake_time >= 1.72:
            self.mood = "calm"
            self.blink_phase = "open"
            self.openness = 1.0
            self.set_attention(0.0, 0.0)
            self.reaction_lock_until = self.elapsed + 0.30
            self.decision_due = self.elapsed + self.random.uniform(2.6, 5.2)
            self.next_blink = self.elapsed + self.random.uniform(*BLINK_INTERVAL)
            if self.requested_colour_index != self.colour_index:
                self.colour_transition_count += 1
                self.begin_blink("colour")
            else:
                self.schedule_voice("wake", delay=0.24, probability=0.20)

    def update_rouse(self, elapsed):
        self.rouse_time += elapsed
        progress = smoothstep(self.rouse_time / 0.82)
        self.openness = self.rouse_start_openness + (1.0 - self.rouse_start_openness) * progress
        if self.rouse_time >= 0.82:
            self.mood = "calm"
            self.openness = 1.0
            self.expression = "calm"
            self.expression_until = self.elapsed
            self.reaction_lock_until = self.elapsed + 0.18
            self.decision_due = self.elapsed + self.random.uniform(2.8, 5.4)
            self.next_blink = self.elapsed + self.random.uniform(*BLINK_INTERVAL)

    def update_blink(self, elapsed):
        if self.blink_phase in ("open", "sleeping"):
            return
        if self.blink_phase == "startup":
            return
        self.blink_time += elapsed
        close_time = 0.075 if self.blink_kind == "colour" else 0.095
        hold_time = 0.075 if self.blink_kind == "colour" else 0.035
        open_time = 0.15 if self.mood != "sleepy" else 0.32
        if self.blink_phase == "closing":
            self.openness = self.blink_start_openness * (1.0 - smoothstep(self.blink_time / close_time))
            if self.blink_time >= close_time:
                self.openness = 0.0
                self.blink_phase = "closed"
                self.blink_time = 0.0
                if self.blink_kind == "colour":
                    self.colour_index = self.requested_colour_index
                    self.save_colour()
        elif self.blink_phase == "closed":
            if self.blink_time >= hold_time:
                self.blink_phase = "opening"
                self.blink_time = 0.0
        elif self.blink_phase == "opening":
            self.openness = self.blink_rest_openness * smoothstep(self.blink_time / open_time)
            if self.blink_time >= open_time:
                self.openness = self.blink_rest_openness
                self.blink_phase = "open"
                if self.double_blink_pending:
                    self.double_blink_pending = False
                    self.next_blink = self.elapsed + 0.16
                else:
                    multiplier = 1.45 if self.mood == "sleepy" else 1.0
                    self.next_blink = self.elapsed + self.random.uniform(*BLINK_INTERVAL) * multiplier
                if self.blink_kind == "colour":
                    if self.colour_index != self.requested_colour_index:
                        self.colour_transition_count += 1
                        self.begin_blink("colour")
                    else:
                        self.schedule_voice("acknowledge", delay=0.18,
                                            probability=0.38)

    def update(self, elapsed):
        elapsed = min(0.1, max(0.0, elapsed))
        self.elapsed += elapsed
        self.idle += elapsed
        self.stimulation = max(0.0, self.stimulation - STIMULUS_DECAY * elapsed)
        self.irritation = max(0.0, self.irritation - IRRITATION_DECAY * elapsed)
        self.curiosity = approach(self.curiosity, 0.62, CURIOSITY_RECOVERY, elapsed)
        self.comfort = approach(self.comfort, 0.72, COMFORT_RECOVERY, elapsed)
        self.interest_in_user = approach(self.interest_in_user, 0.45,
                                         INTEREST_DECAY, elapsed)

        if self.pending_reaction:
            remaining = self.pending_reaction["due"] - self.elapsed
            target = 1.0 if 0.0 < remaining < 0.13 else 0.0
            self.anticipation = approach(self.anticipation, target, 18.0, elapsed)
        else:
            self.anticipation = approach(self.anticipation, 0.0, 14.0, elapsed)
        self.apply_pending_reaction()
        self.apply_idle_followup()
        self.update_contact()

        if self.mood == "waking":
            self.update_startup(elapsed)
        elif self.mood == "rousing":
            self.update_rouse(elapsed)
        elif self.idle >= IDLE_ASLEEP:
            if self.mood != "asleep":
                self.sleep_progress = 0.0
                self.sleep_start_openness = clamp(self.openness)
                if self.blink_phase == "open":
                    self.asymmetry = 0.0
                self.blink_phase = "sleeping"
                self.double_blink_pending = False
            self.mood = "asleep"
            self.sleep_progress = clamp(self.sleep_progress + elapsed / SLEEP_CLOSE_TIME)
            self.openness = self.sleep_start_openness * (1.0 - smoothstep(self.sleep_progress))
            self.return_attention_to_rest()
        elif self.idle >= IDLE_SLEEPY:
            self.mood = "sleepy"
            self.expression = "sleepy"
            self.return_attention_to_rest()
            if self.blink_phase == "open":
                self.openness = approach(self.openness, 0.62, 0.45, elapsed)
            if self.blink_phase == "open" and self.elapsed >= self.next_blink:
                self.begin_blink("sleepy")
            if not self.sleepy_voice_used and self.idle > IDLE_SLEEPY + 18.0:
                self.sleepy_voice_used = True
                self.schedule_voice("sleepy", probability=0.28)
        else:
            self.sleepy_voice_used = False
            self.mood = "attentive" if self.stimulation > 0.42 else "calm"
            if self.blink_phase == "open":
                self.openness = approach(self.openness, 1.0, 8.0, elapsed)
            if self.elapsed >= self.next_blink and self.blink_phase == "open":
                self.begin_blink()
            if (self.elapsed >= self.decision_due and self.blink_phase == "open" and
                    not self.pending_reaction and not self.idle_followup and
                    not self.stimulus_count and self.expression == "calm"):
                self.choose_attention()

        if (self.stimulus_count and self.mood not in ("waking", "rousing") and
                self.elapsed >= self.stimulus_due and
                self.elapsed >= self.reaction_lock_until and
                self.pending_reaction is None):
            self.consume_stimulus()

        if self.elapsed >= self.expression_until and self.expression not in ("sleepy",):
            self.expression = "calm"
            self.reactive_expression = False

        self.update_blink(elapsed)
        self.update_wink(elapsed)
        if self.attention_return_due and self.elapsed >= self.attention_return_due:
            self.return_attention_to_rest()
        if self.correction_pending and self.elapsed >= self.correction_due:
            self.correction_pending = False
            self.target_x = clamp(self.target_x + self.random.uniform(-0.065, 0.065), -1.0, 1.0)
            self.target_y = clamp(self.target_y + self.random.uniform(-0.04, 0.04), -1.0, 1.0)
        self.attention_x = approach(self.attention_x, self.target_x, self.shift_speed, elapsed)
        self.attention_y = approach(self.attention_y, self.target_y, self.shift_speed, elapsed)
        self.update_expression_pose(elapsed)
        self.update_voice()
        self.update_intention()

    def geometry(self):
        width_scale = self.pose_width
        height_scale = self.pose_height * (1.0 - 0.055 * self.anticipation)
        spacing = self.pose_spacing
        vertical = self.pose_vertical
        left_scale = self.pose_left_scale
        right_scale = self.pose_right_scale
        left_offset = self.pose_left_offset
        right_offset = self.pose_right_offset

        if self.mood == "waking" and 0.52 <= self.wake_time < 1.08:
            if self.wake_left_first:
                right_scale *= 0.48
            else:
                left_scale *= 0.48

        openness = clamp(self.openness)
        base_width = 184.0 * width_scale
        base_height = 154.0 * height_scale
        height = base_height * openness
        move_x = self.attention_x * 46.0
        move_y = self.attention_y * 34.0 + vertical
        centre_y = 240.0 + move_y
        asymmetry = self.asymmetry * (1.0 - openness) if self.blink_phase != "open" else 0.0
        left_height = max(4.0, height * left_scale * (1.0 - asymmetry) * self.left_wink)
        right_height = max(4.0, height * right_scale * (1.0 + asymmetry) * self.right_wink)
        centre_x = 320.0 + move_x
        result = EyeGeometry(
            centre_x - spacing / 2.0,
            centre_x + spacing / 2.0,
            centre_y + left_offset,
            centre_y + right_offset,
            base_width * self.pose_left_width,
            base_width * self.pose_right_width,
            left_height,
            right_height,
        )
        return result


def rounded_eye_rectangles(centre_x, centre_y, width, height):
    width = max(4, int(round(width)))
    height = max(4, int(round(height)))
    left = int(round(centre_x - width / 2))
    top = int(round(centre_y - height / 2))
    if height < 7:
        return ((left, top, width, height),)
    band = 3
    half_width = width / 2.0
    half_height = height / 2.0
    shape_power = 4.0
    rectangles = []
    for y in range(0, height, band):
        band_height = min(band, height - y)
        sample_y = y + band_height * 0.5
        normal_y = min(1.0, abs((sample_y - half_height) / half_height))
        half_span = half_width * max(0.0, 1.0 - normal_y ** shape_power) ** (1.0 / shape_power)
        inset = int(round((half_width - half_span) / 2.0) * 2)
        span = max(4, width - inset * 2)
        rectangles.append((left + inset, top + y, span, band_height))
    return tuple(rectangles)


def geometry_rectangles(geometry):
    rectangles = rounded_eye_rectangles(geometry.left_x, geometry.left_y,
                                         geometry.left_width, geometry.left_height)
    rectangles += rounded_eye_rectangles(geometry.right_x, geometry.right_y,
                                          geometry.right_width, geometry.right_height)
    return rectangles


def render_rectangles(momo):
    return geometry_rectangles(momo.geometry())


def geometry_key(geometry):
    return tuple(round(value, 2) for value in geometry.__dict__.values())


def frame_pacing_delay(deadline, now):
    deadline += FRAME_STEP
    if now - deadline > FRAME_STEP:
        deadline = now
    remaining = deadline - now
    return deadline, math.ceil(remaining * 1000) if remaining >= 0.002 else 0


class SDLRect(ctypes.Structure):
    _fields_ = (("x", ctypes.c_int), ("y", ctypes.c_int),
                ("w", ctypes.c_int), ("h", ctypes.c_int))


class SDLKeysym(ctypes.Structure):
    _fields_ = (("scancode", ctypes.c_int), ("sym", ctypes.c_int),
                ("mod", ctypes.c_uint16), ("unused", ctypes.c_uint32))


class SDLKeyboardEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("window_id", ctypes.c_uint32), ("state", ctypes.c_uint8),
                ("repeat", ctypes.c_uint8), ("padding2", ctypes.c_uint8),
                ("padding3", ctypes.c_uint8), ("keysym", SDLKeysym))


class SDLJoyAxisEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("which", ctypes.c_int32), ("axis", ctypes.c_uint8),
                ("padding1", ctypes.c_uint8), ("padding2", ctypes.c_uint8),
                ("padding3", ctypes.c_uint8), ("value", ctypes.c_int16),
                ("padding4", ctypes.c_uint16))


class SDLJoyButtonEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("which", ctypes.c_int32), ("button", ctypes.c_uint8),
                ("state", ctypes.c_uint8), ("padding1", ctypes.c_uint8),
                ("padding2", ctypes.c_uint8))


class SDLMouseMotionEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("window_id", ctypes.c_uint32), ("which", ctypes.c_uint32),
                ("state", ctypes.c_uint32), ("x", ctypes.c_int32),
                ("y", ctypes.c_int32), ("xrel", ctypes.c_int32),
                ("yrel", ctypes.c_int32))


class SDLMouseButtonEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("window_id", ctypes.c_uint32), ("which", ctypes.c_uint32),
                ("button", ctypes.c_uint8), ("state", ctypes.c_uint8),
                ("clicks", ctypes.c_uint8), ("padding1", ctypes.c_uint8),
                ("x", ctypes.c_int32), ("y", ctypes.c_int32))


class SDLEvent(ctypes.Union):
    _fields_ = (("type", ctypes.c_uint32), ("key", SDLKeyboardEvent),
                ("jaxis", SDLJoyAxisEvent), ("jbutton", SDLJoyButtonEvent),
                ("motion", SDLMouseMotionEvent), ("mouse_button", SDLMouseButtonEvent),
                ("padding", ctypes.c_uint8 * 56))


class SDLAudioSpec(ctypes.Structure):
    _fields_ = (("freq", ctypes.c_int), ("format", ctypes.c_uint16),
                ("channels", ctypes.c_uint8), ("silence", ctypes.c_uint8),
                ("samples", ctypes.c_uint16), ("padding", ctypes.c_uint16),
                ("size", ctypes.c_uint32), ("callback", ctypes.c_void_p),
                ("userdata", ctypes.c_void_p))


class Renderer:
    def __init__(self, profile=None):
        self.profile = Path(profile) if profile else None
        self.sdl = None
        for name in ("libSDL2-2.0.so.0", "libSDL2.so", "SDL2.dll"):
            try:
                self.sdl = ctypes.CDLL(name)
                break
            except OSError:
                continue
        if self.sdl is None:
            raise RuntimeError("SDL2 runtime was not found")
        self.bind()
        self.sdl.SDL_SetHint(b"SDL_RENDER_SCALE_QUALITY", b"0")
        if self.sdl.SDL_Init(0x20 | 0x200 | (0x2000 if PORTMASTER else 0)) != 0:
            raise RuntimeError("SDL2 could not initialise video and joystick")
        flags = 4 if os.environ.get("MOMO_WINDOWED") else 0x00001005
        self.window = self.sdl.SDL_CreateWindow(b"MOMO", 0x2FFF0000, 0x2FFF0000,
                                                WIDTH, HEIGHT, flags)
        if not self.window:
            raise RuntimeError("SDL2 could not create the MOMO window")
        self.renderer = self.sdl.SDL_CreateRenderer(self.window, -1, 2 | 4)
        if not self.renderer:
            self.renderer = self.sdl.SDL_CreateRenderer(self.window, -1, 1)
        if not self.renderer:
            raise RuntimeError("SDL2 could not create the MOMO renderer")
        self.sdl.SDL_RenderSetLogicalSize(self.renderer, WIDTH, HEIGHT)
        self.controller = None
        self.joystick = None
        if PORTMASTER:
            for index in range(self.sdl.SDL_NumJoysticks()):
                if self.sdl.SDL_IsGameController(index):
                    self.controller = self.sdl.SDL_GameControllerOpen(index)
                    if self.controller:
                        break
        if not self.controller and self.sdl.SDL_NumJoysticks():
            self.joystick = self.sdl.SDL_JoystickOpen(0)
        self.rectangle_buffer = (SDLRect * 192)()
        self.rectangle_count = 0
        self.rectangle_pointers = tuple(
            ctypes.cast(ctypes.byref(self.rectangle_buffer, index * ctypes.sizeof(SDLRect)),
                        ctypes.POINTER(SDLRect))
            for index in range(len(self.rectangle_buffer))
        )
        self.shade_counts = [0] * (EYE_GRADIENT_STEPS + 1)
        self.shade_starts = [0] * (EYE_GRADIENT_STEPS + 1)
        self.shade_next = [0] * (EYE_GRADIENT_STEPS + 1)
        self.rectangle_shades = [0] * len(self.rectangle_buffer)
        self.cached_geometry_key = None
        raw_voice_buffers = load_voice_bank()
        self.voice_buffers = {
            key: ctypes.create_string_buffer(value)
            for key, value in raw_voice_buffers.items()
        }
        if HANDHELD:
            for key, value in raw_voice_buffers.items():
                source = ctypes.create_string_buffer(value)
                self.sdl.SDL_MixAudioFormat(self.voice_buffers[key], source,
                                            0x8010, len(value), ARKOS_AUDIO_MIX_VOLUME)
        self.audio = 0
        if self.sdl.SDL_InitSubSystem(0x10) == 0:
            wanted = SDLAudioSpec()
            obtained = SDLAudioSpec()
            wanted.freq = AUDIO_RATE
            wanted.format = 0x8010
            wanted.channels = AUDIO_CHANNELS
            wanted.samples = 512
            self.audio = self.sdl.SDL_OpenAudioDevice(
                None, 0, ctypes.byref(wanted), ctypes.byref(obtained), 0)
            if self.audio:
                self.sdl.SDL_PauseAudioDevice(self.audio, 0)
            else:
                self.log_audio_error("SDL_OpenAudioDevice")
        else:
            self.log_audio_error("SDL_InitSubSystem")

    def bind(self):
        for name in ("SDL_CreateWindow", "SDL_CreateRenderer", "SDL_JoystickOpen",
                     "SDL_GameControllerOpen"):
            getattr(self.sdl, name).restype = ctypes.c_void_p
        self.sdl.SDL_GameControllerOpen.argtypes = (ctypes.c_int,)
        self.sdl.SDL_IsGameController.argtypes = (ctypes.c_int,)
        self.sdl.SDL_IsGameController.restype = ctypes.c_int
        self.sdl.SDL_GameControllerClose.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_CreateWindow.argtypes = (ctypes.c_char_p, ctypes.c_int, ctypes.c_int,
                                              ctypes.c_int, ctypes.c_int, ctypes.c_uint32)
        self.sdl.SDL_CreateRenderer.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_uint32)
        self.sdl.SDL_SetHint.argtypes = (ctypes.c_char_p, ctypes.c_char_p)
        self.sdl.SDL_RenderSetLogicalSize.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_int)
        self.sdl.SDL_SetRenderDrawColor.argtypes = (ctypes.c_void_p, ctypes.c_uint8,
                                                    ctypes.c_uint8, ctypes.c_uint8,
                                                    ctypes.c_uint8)
        self.sdl.SDL_RenderClear.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_RenderFillRects.argtypes = (ctypes.c_void_p,
                                                 ctypes.POINTER(SDLRect), ctypes.c_int)
        self.sdl.SDL_RenderPresent.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_PollEvent.argtypes = (ctypes.POINTER(SDLEvent),)
        self.sdl.SDL_JoystickClose.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_DestroyRenderer.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_DestroyWindow.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_Delay.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_OpenAudioDevice.restype = ctypes.c_uint32
        self.sdl.SDL_OpenAudioDevice.argtypes = (
            ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(SDLAudioSpec),
            ctypes.POINTER(SDLAudioSpec), ctypes.c_int)
        self.sdl.SDL_QueueAudio.argtypes = (
            ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32)
        self.sdl.SDL_MixAudioFormat.argtypes = (
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint16,
            ctypes.c_uint32, ctypes.c_int)
        self.sdl.SDL_MixAudioFormat.restype = None
        self.sdl.SDL_PauseAudioDevice.argtypes = (ctypes.c_uint32, ctypes.c_int)
        self.sdl.SDL_CloseAudioDevice.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_GetQueuedAudioSize.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_GetQueuedAudioSize.restype = ctypes.c_uint32
        self.sdl.SDL_GetError.restype = ctypes.c_char_p

    def log_audio_error(self, operation):
        if not self.profile:
            return
        error = self.sdl.SDL_GetError()
        message = error.decode("utf8", "replace") if error else "unknown SDL error"
        try:
            self.profile.mkdir(parents=True, exist_ok=True)
            (self.profile / "audio_error.log").write_text(
                operation + ": " + message + "\n", encoding="utf8")
        except OSError:
            pass

    def play_voice(self, intent, variation):
        if not self.audio or self.sdl.SDL_GetQueuedAudioSize(self.audio):
            return False
        buffer = self.voice_buffers[(intent, variation)]
        return self.sdl.SDL_QueueAudio(
            self.audio, buffer, ctypes.sizeof(buffer) - 1) == 0

    def draw(self, momo):
        self.sdl.SDL_SetRenderDrawColor(self.renderer, 0, 0, 0, 255)
        self.sdl.SDL_RenderClear(self.renderer)
        geometry = momo.geometry()
        key = geometry_key(geometry)
        if key != self.cached_geometry_key:
            left = rounded_eye_rectangles(geometry.left_x, geometry.left_y,
                                          geometry.left_width, geometry.left_height)
            right = rounded_eye_rectangles(geometry.right_x, geometry.right_y,
                                           geometry.right_width, geometry.right_height)
            rectangles = left + right
            if len(rectangles) > len(self.rectangle_buffer):
                raise RuntimeError("MOMO contour exceeds the render buffer")
            for shade in range(EYE_GRADIENT_STEPS + 1):
                self.shade_counts[shade] = 0
            index = 0
            for eye in (left, right):
                top = eye[0][1]
                span = max(1, eye[-1][1] - top)
                for item in eye:
                    shade = min(EYE_GRADIENT_STEPS,
                                ((item[1] - top) * EYE_GRADIENT_STEPS + span // 2) // span)
                    self.rectangle_shades[index] = shade
                    self.shade_counts[shade] += 1
                    index += 1
            position = 0
            for shade, count in enumerate(self.shade_counts):
                self.shade_starts[shade] = position
                self.shade_next[shade] = position
                position += count
            for index, item in enumerate(rectangles):
                shade = self.rectangle_shades[index]
                position = self.shade_next[shade]
                self.rectangle_buffer[position] = SDLRect(*item)
                self.shade_next[shade] = position + 1
            self.rectangle_count = len(rectangles)
            self.cached_geometry_key = key
        colours = EYE_GRADIENT_PALETTE[momo.colour_index]
        for shade, count in enumerate(self.shade_counts):
            if count:
                self.sdl.SDL_SetRenderDrawColor(self.renderer, *colours[shade], 255)
                self.sdl.SDL_RenderFillRects(self.renderer,
                                             self.rectangle_pointers[self.shade_starts[shade]],
                                             count)
        self.sdl.SDL_RenderPresent(self.renderer)

    def close(self):
        if self.audio:
            self.sdl.SDL_CloseAudioDevice(self.audio)
        if getattr(self, "controller", None):
            self.sdl.SDL_GameControllerClose(self.controller)
        if self.joystick:
            self.sdl.SDL_JoystickClose(self.joystick)
        self.sdl.SDL_DestroyRenderer(self.renderer)
        self.sdl.SDL_DestroyWindow(self.window)
        self.sdl.SDL_Quit()


DPAD_INTERACTIONS = {8: "surprise", 9: "soothe", 10: "tease", 11: "greet"}
BUTTON_INTERACTIONS = {0: "startle", 2: "play", 3: "watch",
                       4: "edge_left", 5: "edge_right",
                       6: "flinch", 7: "peek"}
KEY_BUTTONS = {
    82: 8, 81: 9, 80: 10, 79: 11,
    29: 1, 44: 1,
    27: 0,
    4: 4, 22: 5,
    20: 6, 26: 7,
    40: 13, 42: 12,
}


# SDL game controller buttons translated to MOMO's internal R36S button codes.
# PortMaster supplies the mapping per device, so these are standard pad positions.
CONTROLLER_BUTTONS = {
    0: 1,    # A           change eye colour
    1: 0,    # B           startle
    2: 2,    # X           play
    3: 3,    # Y           watch
    4: 12,   # SELECT
    6: 13,   # START
    9: 4,    # L1          edge left
    10: 5,   # R1          edge right
    11: 8,   # D pad up    surprise
    12: 9,   # D pad down  soothe
    13: 10,  # D pad left  tease
    14: 11,  # D pad right greet
}
CONTROLLER_GUIDE = 5
# Triggers are analogue axes on a standard pad; L2 and R2 become buttons 6 and 7.
CONTROLLER_TRIGGERS = {4: 6, 5: 7}
TRIGGER_PRESS = 16000
TRIGGER_RELEASE = 8000


def controller_button(momo, pressed_buttons, button, down):
    """Handle one controller button press or release. Returns True to exit."""
    if button == CONTROLLER_GUIDE:
        return down
    internal = CONTROLLER_BUTTONS.get(button)
    if internal is None:
        return False
    return joystick_button(momo, pressed_buttons, internal, down)


def controller_trigger(momo, pressed_buttons, trigger_state, axis, value):
    """Treat an analogue trigger as a button with a little hysteresis."""
    internal = CONTROLLER_TRIGGERS[axis]
    held = trigger_state.get(axis, False)
    if not held and value > TRIGGER_PRESS:
        trigger_state[axis] = True
        return joystick_button(momo, pressed_buttons, internal, True)
    if held and value < TRIGGER_RELEASE:
        trigger_state[axis] = False
        return joystick_button(momo, pressed_buttons, internal, False)
    return False


def joystick_button(momo, pressed_buttons, button, down):
    """Shared handling for an R36S style button code. Returns True to exit."""
    if update_protected_exit(pressed_buttons, button, down):
        return True
    if down and button not in (12, 13):
        handle_button(momo, button)
    elif not down and button in (4, 5, 6, 7):
        momo.release_shoulder(button)
    return False


def stick_axis(momo, axis_state, axis, value):
    direction = axis_direction(value)
    if direction != axis_state[axis]:
        axis_state[axis] = direction
        if direction:
            if axis in (0, 1):
                momo.stimulus(direction if axis == 0 else 0,
                              direction if axis == 1 else 0, 0.8)
            elif axis == 2:
                momo.interact("edge_left" if direction < 0 else "edge_right")
            else:
                momo.interact("lean_in" if direction < 0 else "withdraw")


def axis_direction(value):
    if value < -14000:
        return -1
    if value > 14000:
        return 1
    return 0


def handle_button(momo, button):
    if button == 1:
        momo.cycle_colour()
    elif button in DPAD_INTERACTIONS:
        momo.interact(DPAD_INTERACTIONS[button])
    elif button in BUTTON_INTERACTIONS:
        momo.interact(BUTTON_INTERACTIONS[button])


def update_protected_exit(pressed_buttons, button, down):
    if down:
        pressed_buttons.add(button)
    else:
        pressed_buttons.discard(button)
    return 12 in pressed_buttons and 13 in pressed_buttons


def handle_key(momo, pressed_buttons, scancode, down, repeat=False):
    if scancode == 41:
        return down
    button = KEY_BUTTONS.get(scancode)
    if button is None:
        return False
    if button in (12, 13):
        return update_protected_exit(pressed_buttons, button, down)
    if down and not repeat:
        handle_button(momo, button)
    elif not down and button in (4, 5, 6, 7):
        momo.release_shoulder(button)
    return False


class WindowsMouseInput:
    """Translate familiar mouse gestures into MOMO's existing stimuli."""

    def __init__(self):
        self.last_position = None
        self.last_motion = None
        self.armed = False
        self.notice_origin = None
        self.hover_side = None
        self.hover_position = None
        self.hover_since = 0.0
        self.hover_sent = False
        self.left_press = None
        self.last_eye_click = None
        self.pending_space_click = None

    @staticmethod
    def eye_at(momo, x, y):
        geometry = momo.geometry()
        for side, centre_x, centre_y, width, height in (
            ("left", geometry.left_x, geometry.left_y,
             geometry.left_width, geometry.left_height),
            ("right", geometry.right_x, geometry.right_y,
             geometry.right_width, geometry.right_height),
        ):
            if (abs(x - centre_x) <= width / 2 + 22 and
                    abs(y - centre_y) <= max(height / 2, 48) + 22):
                return side
        return None

    def motion(self, momo, x, y):
        now = momo.elapsed
        previous = self.last_position
        quiet = self.last_motion is not None and now - self.last_motion >= 2.5
        self.last_position = (x, y)
        self.last_motion = now
        if self.left_press is not None:
            return
        side = self.eye_at(momo, x, y)
        if side != self.hover_side:
            self.hover_side = side
            self.hover_position = (x, y)
            self.hover_since = now
            self.hover_sent = False
        elif side and self.hover_position and (
                (x - self.hover_position[0]) ** 2 +
                (y - self.hover_position[1]) ** 2 > 8 ** 2):
            self.hover_position = (x, y)
            self.hover_since = now
        if previous is None or now < WAKE_LOCK_TIME:
            return
        if quiet:
            self.armed = True
            self.notice_origin = previous
        origin = self.notice_origin
        if self.armed and origin and (
                (x - origin[0]) ** 2 + (y - origin[1]) ** 2 >= 38 ** 2):
            self.armed = False
            self.notice_origin = None
            momo.receive_stimulus("watch", (x - WIDTH / 2) / (WIDTH / 2),
                                  (y - HEIGHT / 2) / (HEIGHT / 2), 0.20)

    def button_down(self, momo, button, x, y):
        self.armed = False
        self.notice_origin = None
        self.last_position = (x, y)
        self.last_motion = momo.elapsed
        if button == 3:
            momo.cycle_colour()
        elif button == 1:
            self.left_press = (momo.elapsed, x, y)
            self.hover_side = None

    def button_up(self, momo, button, x, y):
        if button != 1 or self.left_press is None:
            return
        started, start_x, start_y = self.left_press
        self.left_press = None
        duration = momo.elapsed - started
        dx, dy = x - start_x, y - start_y
        self.last_position = (x, y)
        self.last_motion = momo.elapsed
        if dx * dx + dy * dy >= 55 ** 2:
            self.pending_space_click = None
            self.last_eye_click = None
            magnitude = math.hypot(dx, dy)
            momo.stimulus(dx / magnitude, dy / magnitude, 0.80)
            return
        side = self.eye_at(momo, x, y)
        if duration >= 0.65:
            self.pending_space_click = None
            self.last_eye_click = None
            momo.interact("soothe" if side else "watch")
        elif side:
            self.pending_space_click = None
            prior = self.last_eye_click
            if (prior and prior[0] == side and momo.elapsed - prior[1] <= 0.38 and
                    (x - prior[2]) ** 2 + (y - prior[3]) ** 2 <= 40 ** 2):
                self.last_eye_click = None
                momo.interact("flinch" if side == "left" else "peek")
            else:
                self.last_eye_click = (side, momo.elapsed, x, y)
                momo.interact("edge_left" if side == "left" else "edge_right")
        else:
            prior = self.pending_space_click
            if (prior and momo.elapsed - prior[0] <= 0.38 and
                    (x - prior[1]) ** 2 + (y - prior[2]) ** 2 <= 40 ** 2):
                self.pending_space_click = None
                momo.interact("play")
            else:
                if prior:
                    momo.interact("startle")
                self.pending_space_click = (momo.elapsed, x, y)

    def update(self, momo):
        if (self.pending_space_click and
                momo.elapsed - self.pending_space_click[0] >= 0.38):
            self.pending_space_click = None
            momo.interact("startle")
        if (self.hover_side and not self.hover_sent and self.left_press is None and
                momo.elapsed >= WAKE_LOCK_TIME and
                momo.elapsed - self.hover_since >= 1.0):
            self.hover_sent = True
            momo.interact("soothe")


def run(profile):
    momo = Momo(profile)
    renderer = Renderer(profile)
    platform = PLATFORM
    mouse = WindowsMouseInput() if platform in ("windows", "linux") else None
    power_monitor = (PowerMonitor() if HANDHELD
                     else None)
    trigger_state = {}
    event = SDLEvent()
    axis_state = {0: 0, 1: 0, 2: 0, 3: 0}
    pressed_buttons = set()
    running = True
    previous = time.monotonic()
    frame_deadline = time.perf_counter()
    accumulator = 0.0
    try:
        while running:
            now = time.monotonic()
            elapsed = min(0.08, now - previous)
            previous = now
            accumulator = min(0.1, accumulator + elapsed)
            while renderer.sdl.SDL_PollEvent(ctypes.byref(event)):
                if event.type == 0x100:
                    running = False
                elif mouse and event.type == 0x400:
                    mouse.motion(momo, event.motion.x, event.motion.y)
                elif mouse and event.type == 0x401:
                    mouse.button_down(momo, event.mouse_button.button,
                                      event.mouse_button.x, event.mouse_button.y)
                elif mouse and event.type == 0x402:
                    mouse.button_up(momo, event.mouse_button.button,
                                    event.mouse_button.x, event.mouse_button.y)
                elif not mouse and event.type in (0x300, 0x301):
                    if handle_key(momo, pressed_buttons,
                                  event.key.keysym.scancode,
                                  event.type == 0x300,
                                  bool(event.key.repeat)):
                        running = False
                elif renderer.controller and event.type in (0x651, 0x652):
                    if controller_button(momo, pressed_buttons, event.jbutton.button,
                                         event.type == 0x651):
                        running = False
                elif renderer.controller and event.type == 0x650:
                    axis = event.jaxis.axis
                    if axis in CONTROLLER_TRIGGERS:
                        if controller_trigger(momo, pressed_buttons, trigger_state,
                                              axis, event.jaxis.value):
                            running = False
                    elif axis in axis_state:
                        stick_axis(momo, axis_state, axis, event.jaxis.value)
                elif renderer.controller:
                    pass
                elif not mouse and event.type in (0x603, 0x604):
                    if joystick_button(momo, pressed_buttons, event.jbutton.button,
                                       event.type == 0x603):
                        running = False
                elif not mouse and event.type == 0x600 and event.jaxis.axis in axis_state:
                    stick_axis(momo, axis_state, event.jaxis.axis, event.jaxis.value)
            if mouse:
                mouse.update(momo)
            while accumulator >= BEHAVIOUR_STEP:
                momo.update(BEHAVIOUR_STEP)
                accumulator -= BEHAVIOUR_STEP
            if power_monitor and power_monitor.poll(momo.elapsed):
                momo.power_connected()
            voice = momo.take_voice()
            if voice:
                renderer.play_voice(*voice)
            renderer.draw(momo)
            frame_deadline, delay = frame_pacing_delay(
                frame_deadline, time.perf_counter())
            if delay:
                renderer.sdl.SDL_Delay(delay)
    finally:
        renderer.close()


if __name__ == "__main__":
    profile_path = sys.argv[1] if len(sys.argv) > 1 else str(Path.home() / ".momo")
    run(profile_path)


