## Notes

FORM is an original piece by deadquiet42: an instrument made of light. A small body of points rests on black, still and silent until you touch it. Bend it, twist it, swell it and strike it, and it answers with a slow just tuned voice and bell strikes. Each launch gives a slightly different FORM, with its own little scale, strikes and light. Headphones recommended. Thanks to the PortMaster team and testers.

FORM is a small native program. It draws everything itself and generates all of its sound in real time through the system SDL2 library, with no bundled libraries, samples or fonts.

FORM is freeware, distributed through PortMaster with the author's permission. See `form/licenses/LICENSE.form.txt`.

## Controls

| Button | Action |
|--|--|
| Right Stick | Turn (it keeps turning when you let go) |
| Left Stick | Twist |
| D-Pad | Strike from that side; hold to bend it away |
| A | Expand |
| B | Compress |
| X | Twist sharply |
| Y | Colour |
| L1 | Hold still (damp) |
| R1 | Resonate |
| L2 / R2 | Pull / push |
| L3 | High tick |
| R3 | Low knock |
| A + B, Y + R1, L2 + R2 | Their own chords and shapes |
| Start | Let go of everything |
| Select + Start | Exit |

## Compile

    gcc -O2 -s form.c -o form $(sdl2-config --cflags --libs) -lm -lpthread

Build on an aarch64 device or chroot with the SDL2 development files. The release binary was cross compiled with clang and lld against glibc 2.17.
