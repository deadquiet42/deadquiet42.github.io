STAK
WINDOWS / 2026

ARROW LEFT / RIGHT    MOVE
ARROW UP / DOWN       CHOOSE
Z / X                 ROTATE
SPACE                 DROP / CONFIRM
BACKSPACE             CANCEL
R                     RESTART
HOLD DELETE           RESET BEST
ESC                   EXIT

deadquiet42
small software objects
