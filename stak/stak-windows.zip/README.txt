STAK
MW-004 / WINDOWS / 2026

ARROW LEFT / RIGHT    MOVE
ARROW UP / DOWN       CHOOSE
Z / X                 ROTATE
SPACE                 DROP / CONFIRM
BACKSPACE             CANCEL
R                     RESTART
HOLD DELETE           RESET BEST
ESC                   EXIT

minorworks
small software objects
