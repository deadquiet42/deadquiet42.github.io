## Notes

STAK is an original game by deadquiet42, first made for a homebrew front end on the R36S and adapted here for PortMaster. Thanks to the PortMaster team and testers for the runtime and tooling that make small projects like this easy to share.

STAK is pure Python. It draws everything itself through the system SDL2 library, with no bundled libraries, fonts or sound files, and runs on PortMaster's shared `python_3.11` runtime.

STAK is freeware, distributed through PortMaster with the author's permission. See `stak/licenses/LICENSE.stak.txt`.

## Controls

| Button | Action |
|--|--|
| D-Pad Up / Down | Choose shape |
| D-Pad Left / Right | Move shape |
| Left Stick | Choose and move (where present) |
| L1 / R1 | Turn shape (hold to keep turning) |
| Right Stick Left / Right | Turn shape (where present) |
| A | Drop or confirm |
| B | Cancel |
| Start | Restart prompt |
| Hold Select | Reset best score prompt |
| Select + Start | Exit |

## Saves

The best score is kept in `ports/stak/conf/best.txt`.
