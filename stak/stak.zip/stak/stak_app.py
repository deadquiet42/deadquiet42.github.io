#!/usr/bin/env python3

import ctypes
import math
import os
import random
import struct
from array import array
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path


WIDTH = 640
HEIGHT = 480
FLOOR_Y = 438.0
SPAWN_Y = 112.0
FIXED_STEP = 1.0 / 60.0
ROTATION_STEP = math.radians(15.0)
GRAVITY = 520.0
TRANSITION_DURATION = 3.05
AUTO_SETTLE_AFTER = 2.50
FAIL_BEAT = 0.55
AUDIO_RATE = 48000
AUDIO_CHANNELS = 2
AUDIO_GAIN = 0.40

BLACK = (0, 0, 0)
WHITE = (244, 244, 244)
MID = (145, 145, 145)
DIM = (55, 55, 55)
FADED = (34, 34, 34)
FORM_PALETTE = (
    (0, 255, 236),
    (204, 0, 255),
    (255, 0, 206),
    (33, 255, 37),
    (255, 252, 2),
)
LOGO_BLOCKS = (
    (-4, 6, 4, 8, 0),
    (-2, 3, 2, 6, 2),
    (-3, 1, 3, 3, 4),
)


SCALE = (196.0, 220.0, 247.0, 277.0, 330.0)
LADDER = tuple(frequency * 2 ** octave for octave in range(3) for frequency in SCALE)
KEYS = len(SCALE)
PANS = (0.20, 0.50, 0.80)
LEVELS = (0.62, 1.0)
LIGHTEST = 1.45
HEAVIEST = 2.76


def impact_note(mass):
    amount = (HEAVIEST - mass) / (HEAVIEST - LIGHTEST)
    return max(0, min(len(SCALE) - 1, int(round(amount * (len(SCALE) - 1)))))


def pan_index(x):
    if x < WIDTH * 0.38:
        return 0
    if x > WIDTH * 0.62:
        return 2
    return 1


def level_index(speed):
    return 1 if speed >= 300.0 else 0


def smooth(amount):
    amount = max(0.0, min(1.0, amount))
    return amount * amount * (3.0 - 2.0 * amount)


def note_envelope(note_time, note_duration, attack=0.008, release=0.035):
    if note_time < 0.0 or note_time >= note_duration:
        return 0.0
    return smooth(note_time / attack) * smooth((note_duration - note_time) / release)


def chip_wave(frequency, note_time, duty=0.5):
    cycle = (frequency * note_time) % 1.0
    pulse = 1.0 if cycle < duty else -1.0
    triangle = 1.0 - 4.0 * abs(cycle - 0.5)
    return pulse * 0.30 + triangle * 0.70


def master(values, gain):
    peak = max(abs(value) for value in values) or 1.0
    threshold = 0.55
    compressed = []
    for value in values:
        magnitude = abs(value) * 0.96 / peak
        if magnitude > threshold:
            magnitude = threshold + (magnitude - threshold) / 2.0
        compressed.append(math.copysign(magnitude, value))
    makeup = 0.96 / (max(abs(value) for value in compressed) or 1.0) * gain
    return [max(-0.96, min(0.96, value * makeup)) for value in compressed]


def pack(values):
    samples = [int(value * 32767) for value in values]
    samples[-2:] = (0, 0)
    return struct.pack("<{}h".format(len(samples)), *samples)


def mono_voice(kind, note=0, sample_rate=AUDIO_RATE):
    if kind == "impact":
        duration = 0.11
        frequency = LADDER[note]
        values = []
        for index in range(int(sample_rate * duration)):
            position = index / sample_rate
            voice = chip_wave(frequency * (1.035 - 0.035 * position / duration), position, 0.375)
            values.append(voice * note_envelope(position, duration, 0.006, 0.040) *
                          math.exp(-9.0 * position))
        return values
    duration = 0.05
    values = []
    for index in range(int(sample_rate * duration)):
        position = index / sample_rate
        cycle = (659.3 * position) % 1.0
        values.append((1.0 - 4.0 * abs(cycle - 0.5)) *
                      note_envelope(position, duration, 0.002, 0.020) * math.exp(-70.0 * position))
    return values


def place(values, pan, level=1.0):
    left = level * (1.0 - 0.32 * pan)
    right = level * (0.68 + 0.32 * pan)
    stereo = [0.0] * (len(values) * 2)
    stereo[0::2] = [value * left for value in values]
    stereo[1::2] = [value * right for value in values]
    return pack(stereo)


def phrase_pcm(kind, key=0, sample_rate=AUDIO_RATE, output_scale=1.0):
    if kind == "fail":
        duration = 0.44
        duty = 0.50
        notes = (
            (0.000, 0.155, 329.6, 0.25, 0.70),
            (0.135, 0.155, 246.9, 0.75, 0.72),
            (0.270, 0.165, 196.0, 0.42, 0.78),
        )
    else:
        duty = 0.375
        notes = [
            (0.000, 0.095, LADDER[1 + key], 0.12, 0.72),
            (0.075, 0.095, LADDER[3 + key], 0.88, 0.72),
            (0.150, 0.095, LADDER[4 + key], 0.25, 0.76),
            (0.225, 0.150, LADDER[6 + key], 0.74, 0.88),
        ]
        duration = 0.38
        if kind == "best":
            notes[3] = (0.225, 0.095, LADDER[6 + key], 0.74, 0.84)
            notes.append((0.300, 0.200, LADDER[9 + key], 0.50, 0.80))
            duration = 0.52
    stereo = []
    for index in range(int(sample_rate * duration)):
        position = index / sample_rate
        left = right = 0.0
        for start, length, frequency, pan, level in notes:
            note_time = position - start
            envelope = note_envelope(note_time, length)
            if envelope:
                voice = chip_wave(frequency, note_time, duty) * envelope * level
                left += voice * (1.0 - 0.38 * pan)
                right += voice * (0.62 + 0.38 * pan)
        stereo.extend((left, right))
    return pack(master(stereo, output_scale))


def impact_sounds(pitch, output_scale):
    voice = master(mono_voice("impact", pitch), output_scale * 0.82)
    return {("impact", pitch, pan_number, level_number): place(voice, pan, level)
            for pan_number, pan in enumerate(PANS)
            for level_number, level in enumerate(LEVELS)}


def sound_bank(output_scale=AUDIO_GAIN):
    bank = {}
    for pitch in range(KEYS):
        bank.update(impact_sounds(pitch, output_scale))
    tick = master(mono_voice("settle"), output_scale * 0.16)
    for pan_number, pan in enumerate(PANS):
        bank[("settle", pan_number)] = place(tick, pan)
    bank[("complete", 0)] = phrase_pcm("complete", 0, output_scale=output_scale)
    bank[("fail",)] = phrase_pcm("fail", output_scale=output_scale)
    return bank


def later_sounds(output_scale=AUDIO_GAIN):
    for key in range(1, KEYS):
        yield {("complete", key): phrase_pcm("complete", key, output_scale=output_scale)}
        yield {("best", key): phrase_pcm("best", key, output_scale=output_scale)}
        yield impact_sounds(KEYS - 1 + key, output_scale)
    yield {("best", 0): phrase_pcm("best", 0, output_scale=output_scale)}


def mix_pcm(first, second):
    longer, shorter = (array("h", first), array("h", second))
    if len(longer) < len(shorter):
        longer, shorter = shorter, longer
    for index, value in enumerate(shorter):
        total = longer[index] + value
        longer[index] = 32767 if total > 32767 else -32768 if total < -32768 else total
    return longer.tobytes()

SHAPE_WEIGHTS = (
    ("slab", 7),
    ("disc", 7),
    ("triangle", 15),
    ("beam", 14),
    ("elbow", 16),
    ("wedge", 14),
    ("clipped block", 14),
    ("rocker", 13),
)
SHAPE_NAMES, SHAPE_CHANCES = zip(*SHAPE_WEIGHTS)


def rectangle(width, height, ox=0.0, oy=0.0):
    hw, hh = width / 2.0, height / 2.0
    return ((ox - hw, oy - hh), (ox + hw, oy - hh),
            (ox + hw, oy + hh), (ox - hw, oy + hh))


SHAPES = {
    "slab": ((rectangle(78, 28),), (rectangle(68, 32),)),
    "disc": (tuple((math.cos(i * math.pi / 8) * 25,
                     math.sin(i * math.pi / 8) * 25) for i in range(16)),),
    "triangle": (((0, -31), (31, 25), (-31, 25)),),
    "beam": ((rectangle(104, 18),), (rectangle(92, 21),)),
    "elbow": (rectangle(24, 74, -16, 0), rectangle(64, 24, 4, 25)),
    "wedge": (((-34, 25), (34, 25), (23, -25), (-14, -25)),),
    "clipped block": (((-31, 24), (20, 28), (34, 10), (26, -28),
                         (-17, -30), (-34, -8)),),
    "rocker": (((-36, 7), (-24, -25), (20, -29), (36, 4),
                  (15, 27), (-18, 29)),),
}

VARIANT_SHAPES = frozenset(("slab", "beam"))


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def normalise(vector):
    length = math.hypot(vector[0], vector[1])
    return (vector[0] / length, vector[1] / length) if length else (0.0, 0.0)


def polygon_mass_centre(polygon):
    area_twice = 0.0
    centre_x = 0.0
    centre_y = 0.0
    for index, point in enumerate(polygon):
        following = polygon[(index + 1) % len(polygon)]
        amount = cross(point, following)
        area_twice += amount
        centre_x += (point[0] + following[0]) * amount
        centre_y += (point[1] + following[1]) * amount
    if abs(area_twice) < 0.001:
        return 0.0, (sum(x for x, _ in polygon) / len(polygon),
                     sum(y for _, y in polygon) / len(polygon))
    return abs(area_twice) / 2.0, (centre_x / (3.0 * area_twice),
                                   centre_y / (3.0 * area_twice))


def centre_parts(parts):
    measurements = [polygon_mass_centre(polygon) for polygon in parts]
    mass = sum(item[0] for item in measurements)
    centre_x = sum(item[0] * item[1][0] for item in measurements) / mass
    centre_y = sum(item[0] * item[1][1] for item in measurements) / mass
    return tuple(tuple((x - centre_x, y - centre_y) for x, y in polygon)
                 for polygon in parts)


for shape_name in tuple(SHAPES):
    if shape_name in VARIANT_SHAPES:
        SHAPES[shape_name] = tuple(centre_parts(parts) for parts in SHAPES[shape_name])
    else:
        SHAPES[shape_name] = centre_parts(SHAPES[shape_name])


@dataclass(frozen=True)
class Piece:
    shape: str
    colour: tuple
    variant: int = 0


def piece_parts(piece):
    variants = SHAPES[piece.shape]
    if piece.shape in VARIANT_SHAPES:
        return variants[piece.variant % len(variants)]
    return variants


class Body:
    def __init__(self, piece, x=WIDTH / 2, y=74.0, angle=0.0):
        self.piece = piece
        self.x = float(x)
        self.y = float(y)
        self.angle = float(angle)
        self.vx = 0.0
        self.vy = 0.0
        self.angular_velocity = 0.0
        self.sleeping = False
        self.sounded = False
        self.flash = 0.0
        self.contact_time = 0.0
        self._geometry_pose = None
        self._parts_cache = None
        self._bounds_cache = None
        self._vertical_cache = {}
        self.mass = self._area() / 1200.0
        self.inverse_mass = 1.0 / self.mass
        radius = max(math.hypot(x, y) for part in self.local_parts for x, y in part)
        self.inertia = max(1.0, self.mass * radius * radius * 0.45)
        self.inverse_inertia = 1.0 / self.inertia

    @property
    def local_parts(self):
        return piece_parts(self.piece)

    def _area(self):
        area = 0.0
        for polygon in self.local_parts:
            area += abs(sum(cross(polygon[i], polygon[(i + 1) % len(polygon)])
                            for i in range(len(polygon)))) / 2.0
        return area

    def parts(self, y_offset=0.0):
        pose = (self.x, self.y, self.angle)
        if y_offset == 0.0 and pose == self._geometry_pose:
            return self._parts_cache
        cosine, sine = math.cos(self.angle), math.sin(self.angle)
        result = []
        for polygon in self.local_parts:
            result.append(tuple((self.x + x * cosine - y * sine,
                                 self.y + y_offset + x * sine + y * cosine)
                                for x, y in polygon))
        result = tuple(result)
        if y_offset == 0.0:
            if pose != self._geometry_pose:
                self._bounds_cache = None
                self._vertical_cache = {}
            self._geometry_pose = pose
            self._parts_cache = result
        return result

    def parts_at(self, x, y, angle):
        cosine, sine = math.cos(angle), math.sin(angle)
        return tuple(
            tuple((x + px * cosine - py * sine,
                   y + px * sine + py * cosine)
                  for px, py in polygon)
            for polygon in self.local_parts
        )

    def bounds(self):
        self.parts()
        if self._bounds_cache is None:
            vertices = tuple(point for polygon in self._parts_cache for point in polygon)
            self._bounds_cache = (
                min(x for x, _ in vertices), min(y for _, y in vertices),
                max(x for x, _ in vertices), max(y for _, y in vertices),
            )
        return self._bounds_cache

    def vertical_at(self, x):
        self.parts()
        if x not in self._vertical_cache:
            self._vertical_cache[x] = vertical_extent(self._parts_cache, x)
        return self._vertical_cache[x]

    def all_vertices(self):
        return tuple(point for polygon in self.parts() for point in polygon)


def polygon_projection(polygon, axis):
    values = [dot(point, axis) for point in polygon]
    return min(values), max(values)


def polygon_center(polygon):
    return (sum(point[0] for point in polygon) / len(polygon),
            sum(point[1] for point in polygon) / len(polygon))


def sat_collision(first, second):
    smallest = float("inf")
    collision_axis = None
    for polygon in (first, second):
        for index, point in enumerate(polygon):
            following = polygon[(index + 1) % len(polygon)]
            axis = normalise((-(following[1] - point[1]), following[0] - point[0]))
            first_min, first_max = polygon_projection(first, axis)
            second_min, second_max = polygon_projection(second, axis)
            overlap = min(first_max, second_max) - max(first_min, second_min)
            if overlap <= 0.0:
                return None
            if overlap < smallest:
                smallest = overlap
                collision_axis = axis
    direction = (polygon_center(second)[0] - polygon_center(first)[0],
                 polygon_center(second)[1] - polygon_center(first)[1])
    if dot(direction, collision_axis) < 0:
        collision_axis = (-collision_axis[0], -collision_axis[1])
    return collision_axis, smallest


def body_collision(first, second):
    return parts_collision(first.parts(), second.parts())


def parts_collision(first_parts, second_parts):
    best = None
    for first_part in first_parts:
        for second_part in second_parts:
            collision = sat_collision(first_part, second_part)
            if collision and (best is None or collision[1] > best[1]):
                best = collision
    return best


def aabb_gap(first, second):
    first_box = body_bounds(first)
    second_box = body_bounds(second)
    gap_x = max(0.0, first_box[0] - second_box[2], second_box[0] - first_box[2])
    gap_y = max(0.0, first_box[1] - second_box[3], second_box[1] - first_box[3])
    return math.hypot(gap_x, gap_y)


def body_bounds(body):
    return body.bounds()


def parts_bounds(parts):
    vertices = tuple(point for polygon in parts for point in polygon)
    return (min(x for x, _ in vertices), min(y for _, y in vertices),
            max(x for x, _ in vertices), max(y for _, y in vertices))


def vertical_extent(polygons, x):
    intersections = []
    for polygon in polygons:
        for index, first in enumerate(polygon):
            second = polygon[(index + 1) % len(polygon)]
            left, right = sorted((first[0], second[0]))
            if not left - 0.001 <= x <= right + 0.001:
                continue
            if abs(second[0] - first[0]) < 0.001:
                intersections.extend((first[1], second[1]))
            else:
                amount = (x - first[0]) / (second[0] - first[0])
                if -0.001 <= amount <= 1.001:
                    intersections.append(first[1] + amount * (second[1] - first[1]))
    if not intersections:
        return None
    return min(intersections), max(intersections)


def contact_x_values(upper, lower, tolerance=5.0):
    upper_parts = upper.parts()
    lower_parts = lower.parts()
    upper_box = body_bounds(upper)
    lower_box = body_bounds(lower)
    left = max(upper_box[0], lower_box[0])
    right = min(upper_box[2], lower_box[2])
    if right < left:
        return []
    samples = {left, right}
    samples.update(x for polygon in upper_parts for x, _ in polygon if left <= x <= right)
    samples.update(x for polygon in lower_parts for x, _ in polygon if left <= x <= right)
    first_sample = int(math.ceil(left / 2.0) * 2)
    samples.update(range(first_sample, int(math.floor(right)) + 1, 2))
    contacts = []
    for x in samples:
        upper_extent = upper.vertical_at(x)
        lower_extent = lower.vertical_at(x)
        if upper_extent is None or lower_extent is None:
            continue
        gap = lower_extent[0] - upper_extent[1]
        if -2.0 <= gap <= tolerance:
            contacts.append(float(x))
    return contacts


def body_contact_point(first, second, contacts=None):
    upper, lower = (first, second) if first.y < second.y else (second, first)
    contacts = contacts if contacts is not None else contact_x_values(upper, lower, 8.0)
    if not contacts:
        return ((first.x + second.x) / 2.0, (first.y + second.y) / 2.0)
    reference_x = (second.x if first.sleeping else first.x if second.sleeping
                   else (first.x + second.x) / 2.0)
    contact_x = min(max(reference_x, min(contacts)), max(contacts))
    upper_extent = vertical_extent(upper.parts(), contact_x)
    lower_extent = vertical_extent(lower.parts(), contact_x)
    if upper_extent is None or lower_extent is None:
        return (contact_x, (first.y + second.y) / 2.0)
    return (contact_x, (upper_extent[1] + lower_extent[0]) / 2.0)


class Game:
    def __init__(self, profile, seed=None):
        self.profile = Path(profile)
        self.persistence_available = True
        try:
            self.profile.mkdir(parents=True, exist_ok=True)
        except OSError:
            self.persistence_available = False
        self.random = random.Random(seed)
        self.best = self.load_best()
        self.score = 0
        self.state = "start"
        self.queue = [self.random_piece() for _ in range(3)]
        self.queue_angles = [self.random_start_angle(piece) for piece in self.queue]
        self.queue_index = 0
        self.held_x = WIDTH / 2
        self.held_angle = self.queue_angles[0]
        self.held_moved = False
        self.held_rotated = False
        self.bodies = []
        self.stable_time = 0.0
        self.invalid_time = 0.0
        self.physics_accumulator = 0.0
        self.last_physics_steps = 0
        self.dropped_physics_time = 0.0
        self._contact_cache = {}
        self.state_time = 0.0
        self.blocks_used = 0
        self.new_best = False
        self.buttons = set()
        self.select_held = 0.0
        self.confirm_return_state = "start"
        self.running = True
        self.audio_events = []
        self.display_x = self.held_x
        self.display_angle = self.held_angle
        self.sway_time = 10.0
        self.sway_amount = 0.0
        self.sway_direction = 1.0

    def random_piece(self):
        shape = self.random.choices(SHAPE_NAMES, weights=SHAPE_CHANCES, k=1)[0]
        variant_count = len(SHAPES[shape]) if shape in VARIANT_SHAPES else 1
        return Piece(shape, self.random.choice(FORM_PALETTE),
                     self.random.randrange(variant_count))

    def random_start_angle(self, piece):
        if piece.shape == "disc":
            return 0.0
        return self.random.choice((-5, -4, -3, -2, -1, 1, 2, 3, 4, 5)) * ROTATION_STEP

    def reset_held_pose(self):
        self.held_angle = self.queue_angles[self.queue_index]
        if self.selected_piece().shape == "disc":
            self.held_x = WIDTH / 2 + self.random.choice((-60.0, 60.0))
        else:
            self.held_x = WIDTH / 2
        self.held_moved = False
        self.held_rotated = False
        self.display_x = self.held_x
        self.display_angle = self.held_angle

    def load_best(self):
        if not self.persistence_available:
            return 0
        try:
            return max(0, int((self.profile / "best.txt").read_text(encoding="ascii").strip()))
        except (OSError, ValueError):
            return 0

    def save_best(self):
        if not self.persistence_available:
            return False
        temporary = self.profile / "best.tmp"
        try:
            temporary.write_text(str(self.best) + "\n", encoding="ascii")
            os.replace(temporary, self.profile / "best.txt")
            return True
        except OSError:
            self.persistence_available = False
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            return False

    def contact_values(self, upper, lower, tolerance):
        key = (id(upper), upper.x, upper.y, upper.angle,
               id(lower), lower.x, lower.y, lower.angle, tolerance)
        contacts = self._contact_cache.get(key)
        if contacts is None:
            contacts = tuple(contact_x_values(upper, lower, tolerance))
            self._contact_cache[key] = contacts
        return contacts

    def start_run(self):
        self.score = 0
        self.new_best = False
        self.state = "playing"
        self.new_level()

    def new_level(self):
        self.bodies = []
        self.blocks_used = 0
        self.stable_time = 0.0
        self.invalid_time = 0.0
        self.physics_accumulator = 0.0
        self.state_time = 0.0
        self.queue_index = min(self.queue_index, 2)
        self.queue_angles = [self.random_start_angle(piece) for piece in self.queue]
        self.reset_held_pose()

    def selected_piece(self):
        return self.queue[self.queue_index]

    def choose(self, direction):
        if self.state == "playing" and self.ready_for_piece():
            self.queue_index = (self.queue_index + direction) % 3
            self.reset_held_pose()

    def move(self, direction):
        if self.state == "playing" and self.ready_for_piece():
            self.held_x = max(58.0, min(WIDTH - 58.0, self.held_x + direction * 10.0))
            self.held_moved = True

    def rotate(self, direction):
        if self.state == "playing" and self.ready_for_piece():
            self.held_angle += direction * ROTATION_STEP
            self.queue_angles[self.queue_index] = self.held_angle
            self.held_rotated = True

    def ready_for_piece(self):
        return self.blocks_used < 6 and (not self.bodies or self.is_stable())

    def drop(self):
        if not self.ready_for_piece():
            return False
        piece = self.queue.pop(self.queue_index)
        self.queue_angles.pop(self.queue_index)
        replacement = self.random_piece()
        self.queue.append(replacement)
        self.queue_angles.append(self.random_start_angle(replacement))
        self.queue_index = min(self.queue_index, 2)
        body = Body(piece, self.held_x, SPAWN_Y, self.held_angle)
        body.vy = 8.0
        self.bodies.append(body)
        self.blocks_used += 1
        self.reset_held_pose()
        self.stable_time = 0.0
        self.invalid_time = 0.0
        return True

    def request_restart(self):
        if self.state in ("playing", "transition"):
            self.confirm_return_state = self.state
            self.state = "confirm_restart"
            self.state_time = 0.0

    def request_reset_best(self):
        if self.state != "confirm_reset":
            self.confirm_return_state = self.state
            self.state = "confirm_reset"
            self.state_time = 0.0

    def confirm(self):
        if self.state == "start":
            self.start_run()
        elif self.state == "playing":
            self.drop()
        elif self.state == "result" and self.state_time >= FAIL_BEAT:
            self.start_run()
        elif self.state == "confirm_restart":
            self.start_run()
        elif self.state == "confirm_reset":
            self.best = 0
            self.save_best()
            self.state = self.confirm_return_state
            self.select_held = 0.0

    def cancel(self):
        if self.state == "confirm_restart":
            self.state = self.confirm_return_state
        elif self.state == "confirm_reset":
            self.state = self.confirm_return_state
            self.select_held = 0.0

    def fail(self):
        if self.state != "playing":
            return
        self.new_best = self.score > self.best
        if self.new_best:
            self.best = self.score
            self.save_best()
        self.state = "result"
        self.state_time = 0.0
        self.audio_events.append(("fail",))

    def complete_level(self):
        if self.state == "playing":
            self.state = "transition"
            self.state_time = 0.0
            kind = "best" if self.score + 1 > self.best and not self.new_best else "complete"
            self.audio_events.append((kind, (self.score + 1) % KEYS))

    def finish_transition(self):
        self.score += 1
        if self.score > self.best:
            self.best = self.score
            self.new_best = True
            self.save_best()
        self.state = "playing"
        self.new_level()

    def emit_impact(self, body, speed):
        if body.sounded or speed < 18.0 or self.state != "playing":
            return
        body.sounded = True
        body.flash = 1.0
        self.audio_events.append(("impact", impact_note(body.mass) + self.score % KEYS,
                                  pan_index(body.x), level_index(speed)))
        if len(self.bodies) > 1:
            self.sway_time = 0.0
            self.sway_amount = min(1.0, speed / 300.0)
            self.sway_direction = 1.0 if body.x >= self.bodies[0].x else -1.0

    def settled(self):
        if self.blocks_used == 6:
            self.complete_level()
        elif self.state == "playing":
            self.audio_events.append(("settle", pan_index(self.bodies[-1].x)))

    def is_stable(self):
        return bool(self.bodies) and all(body.sleeping for body in self.bodies)

    def connected(self):
        if not self.bodies:
            return False
        links = {index: set() for index in range(len(self.bodies))}
        grounded = set()
        for index, body in enumerate(self.bodies):
            if max(y for _, y in body.all_vertices()) >= FLOOR_Y - 4.0:
                grounded.add(index)
            for other_index in range(index + 1, len(self.bodies)):
                other = self.bodies[other_index]
                upper, lower = ((body, other) if body.y < other.y
                                else (other, body))
                if self.contact_values(upper, lower, 7.0):
                    links[index].add(other_index)
                    links[other_index].add(index)
        if not grounded:
            return False
        first_grounded = min(grounded)
        reached = {first_grounded}
        pending = [first_grounded]
        while pending:
            index = pending.pop()
            for neighbour in links[index] - reached:
                reached.add(neighbour)
                pending.append(neighbour)
        return len(reached) == len(self.bodies)

    def tower_valid(self):
        if not self.bodies:
            return False
        bounds = [body_bounds(body) for body in self.bodies]
        grounded = [index for index, box in enumerate(bounds)
                    if box[3] >= FLOOR_Y - 0.5]
        if grounded != [0]:
            return False

        support_map = {}
        for index in range(1, len(self.bodies)):
            body = self.bodies[index]
            supporters = []
            contacts = []
            for other_index in range(index):
                other = self.bodies[other_index]
                if other.y <= body.y or aabb_gap(body, other) > 7.0:
                    continue
                direct_contacts = self.contact_values(body, other, 7.0)
                if direct_contacts:
                    supporters.append(other_index)
                    contacts.extend(direct_contacts)
            if not supporters:
                return False
            support_map[index] = (supporters, min(contacts), max(contacts))

        if not self.connected():
            return False

        for index in range(1, len(self.bodies)):
            _, support_left, support_right = support_map[index]
            if not support_left - 3.0 <= self.bodies[index].x <= support_right + 3.0:
                return False
        return True

    def support_span(self, body, tolerance=7.0):
        contacts = []
        vertices = body.all_vertices()
        lowest = max(y for _, y in vertices)
        if lowest >= FLOOR_Y - tolerance:
            contacts.extend(x for x, y in vertices if y >= lowest - 4.0)
        for other in self.bodies:
            if other is body or other.y <= body.y or aabb_gap(body, other) > tolerance:
                continue
            contacts.extend(self.contact_values(body, other, tolerance))
        if not contacts:
            return None
        return min(contacts), max(contacts)

    def resolve_floor(self, body):
        vertices = body.all_vertices()
        lowest = max(y for _, y in vertices)
        penetration = lowest - FLOOR_Y
        if penetration <= 0:
            return
        contacts = [point for point in vertices if point[1] >= lowest - 4.0]
        contact_x = min(max(body.x, min(point[0] for point in contacts)),
                        max(point[0] for point in contacts))
        body.y -= penetration
        arm = contact_x - body.x
        contact_velocity = body.vy + body.angular_velocity * arm
        self.emit_impact(body, contact_velocity)
        if contact_velocity > 0:
            denominator = body.inverse_mass + arm * arm * body.inverse_inertia
            impulse = -contact_velocity / max(denominator, 0.001)
            body.vy += impulse * body.inverse_mass
            body.angular_velocity += arm * impulse * body.inverse_inertia
        body.vx *= 0.985
        body.angular_velocity *= 0.985

    def resolve_pair(self, first, second):
        if aabb_gap(first, second) > 0.0:
            return
        collision = body_collision(first, second)
        if not collision:
            return
        normal, penetration = collision
        first_inverse = 0.0 if first.sleeping else first.inverse_mass
        second_inverse = 0.0 if second.sleeping else second.inverse_mass
        first_inertia = 0.0 if first.sleeping else first.inverse_inertia
        second_inertia = 0.0 if second.sleeping else second.inverse_inertia
        total_inverse = first_inverse + second_inverse
        if total_inverse <= 0.0:
            return
        correction = max(0.0, penetration - 0.05) * 0.94 / total_inverse
        first.x -= normal[0] * correction * first_inverse
        first.y -= normal[1] * correction * first_inverse
        second.x += normal[0] * correction * second_inverse
        second.y += normal[1] * correction * second_inverse

        upper, lower = (first, second) if first.y < second.y else (second, first)
        contacts = self.contact_values(upper, lower, 8.0)
        contact = body_contact_point(first, second, contacts)
        first_arm = (contact[0] - first.x, contact[1] - first.y)
        second_arm = (contact[0] - second.x, contact[1] - second.y)
        first_velocity = (first.vx - first.angular_velocity * first_arm[1],
                          first.vy + first.angular_velocity * first_arm[0])
        second_velocity = (second.vx - second.angular_velocity * second_arm[1],
                           second.vy + second.angular_velocity * second_arm[0])
        relative = (second_velocity[0] - first_velocity[0],
                    second_velocity[1] - first_velocity[1])
        normal_speed = dot(relative, normal)
        if normal_speed > 0:
            return
        active = second if first.sleeping else first
        self.emit_impact(active, -normal_speed)
        first_cross = cross(first_arm, normal)
        second_cross = cross(second_arm, normal)
        denominator = (total_inverse + first_cross * first_cross * first_inertia +
                       second_cross * second_cross * second_inertia)
        impulse = -normal_speed / max(denominator, 0.001)
        impulse_vector = (normal[0] * impulse, normal[1] * impulse)
        first.vx -= impulse_vector[0] * first_inverse
        first.vy -= impulse_vector[1] * first_inverse
        second.vx += impulse_vector[0] * second_inverse
        second.vy += impulse_vector[1] * second_inverse
        first.angular_velocity -= cross(first_arm, impulse_vector) * first_inertia
        second.angular_velocity += cross(second_arm, impulse_vector) * second_inertia

        tangent = normalise((relative[0] - normal_speed * normal[0],
                             relative[1] - normal_speed * normal[1]))
        first_tangent_cross = cross(first_arm, tangent)
        second_tangent_cross = cross(second_arm, tangent)
        tangent_denominator = (total_inverse +
                               first_tangent_cross * first_tangent_cross * first_inertia +
                               second_tangent_cross * second_tangent_cross * second_inertia)
        tangent_impulse = -dot(relative, tangent) / max(tangent_denominator, 0.001)
        tangent_impulse = max(-impulse * 0.55, min(impulse * 0.55, tangent_impulse))
        tangent_vector = (tangent[0] * tangent_impulse, tangent[1] * tangent_impulse)
        first.vx -= tangent[0] * tangent_impulse * first_inverse
        first.vy -= tangent[1] * tangent_impulse * first_inverse
        second.vx += tangent[0] * tangent_impulse * second_inverse
        second.vy += tangent[1] * tangent_impulse * second_inverse
        first.angular_velocity -= cross(first_arm, tangent_vector) * first_inertia
        second.angular_velocity += cross(second_arm, tangent_vector) * second_inertia

    def kinematically_calm(self, previous_poses):
        active = [body for body in self.bodies if not body.sleeping]
        if not active:
            return False
        motion = max((max(abs(body.x - pose[0]), abs(body.y - pose[1]),
                          abs(body.angle - pose[2]) * 32.0)
                      for body, pose in zip(self.bodies, previous_poses)), default=float("inf"))
        return (motion < 0.12 and
                max(abs(body.vx) for body in active) < 1.5 and
                max(abs(body.vy) for body in active) < 3.0 and
                max(abs(body.angular_velocity) for body in active) < 0.035)

    def preempt_impact(self, body, dt):
        if body.sounded or body.vy < 18.0:
            return
        fall = (body.vy + GRAVITY * dt) * dt
        bounds = body_bounds(body)
        predicted_parts = body.parts_at(
            body.x + body.vx * dt,
            body.y + fall,
            body.angle + body.angular_velocity * dt,
        )
        predicted_bounds = parts_bounds(predicted_parts)
        if predicted_bounds[3] >= FLOOR_Y - 0.5:
            self.emit_impact(body, body.vy)
            return
        for other in self.bodies:
            if other is body or not other.sleeping or other.y <= body.y:
                continue
            other_bounds = body_bounds(other)
            horizontal_overlap = min(bounds[2], other_bounds[2]) - max(bounds[0], other_bounds[0])
            vertical_gap = other_bounds[1] - bounds[3]
            if (horizontal_overlap > 0.0 and -1.0 <= vertical_gap <= fall + 1.5 and
                    parts_collision(predicted_parts, other.parts())):
                self.emit_impact(body, body.vy)
                return

    def simulate(self, dt):
        if self.state not in ("playing", "result"):
            return
        if not any(not body.sleeping for body in self.bodies):
            return
        self._contact_cache = {}
        previous_poses = tuple((body.x, body.y, body.angle) for body in self.bodies)
        for body in self.bodies:
            if body.sleeping:
                continue
            self.preempt_impact(body, dt)
            body.vy += GRAVITY * dt
            body.x += body.vx * dt
            body.y += body.vy * dt
            body.angle += body.angular_velocity * dt
            body.vx *= 0.9985
            body.angular_velocity *= 0.9988
        for _ in range(2):
            for body in self.bodies:
                if not body.sleeping:
                    self.resolve_floor(body)
            for index, first in enumerate(self.bodies):
                for second in self.bodies[index + 1:]:
                    if not (first.sleeping and second.sleeping):
                        self.resolve_pair(first, second)

        if any(max(y for _, y in body.all_vertices()) >= FLOOR_Y - 0.5
               for body in self.bodies[1:]):
            self.fail()
            return

        for body in self.bodies:
            if body.sleeping:
                continue
            support = self.support_span(body, 1.5)
            supported = support is not None
            if supported:
                body.contact_time += dt
                support_left, support_right = support
                if body.x < support_left - 1.0 or body.x > support_right + 1.0:
                    nearest = min(max(body.x, support_left), support_right)
                    lever = body.x - nearest
                    angular_acceleration = GRAVITY * body.mass * lever / body.inertia
                    body.angular_velocity += max(
                        -0.16, min(0.16, angular_acceleration * dt)
                    )
                elif body.contact_time >= 0.18 and abs(body.vy) < 18.0:
                    body.vy = 0.0
                    body.vx *= 0.90
                    contact_width = support_right - support_left
                    body.angular_velocity *= 0.88 if contact_width >= 8.0 else 0.96
                elif -10.0 < body.vy < 0.0:
                    body.vy = 0.0
            else:
                body.contact_time = 0.0
            if supported and body.contact_time >= 0.30:
                if abs(body.vx) < 0.05:
                    body.vx = 0.0
                if abs(body.vy) < 0.05:
                    body.vy = 0.0
                if abs(body.angular_velocity) < 0.004:
                    body.angular_velocity = 0.0

        active = [body for body in self.bodies if not body.sleeping]
        auto_settle = (active and
                       all(body.contact_time >= AUTO_SETTLE_AFTER and
                           abs(body.vx) < 10.0 and abs(body.vy) < 12.0 and
                           abs(body.angular_velocity) < 0.12
                           for body in active) and
                       self.connected())
        if auto_settle:
            for body in self.bodies:
                body.vx = 0.0
                body.vy = 0.0
                body.angular_velocity = 0.0
                body.sleeping = True
            self.stable_time = 0.0
            self.invalid_time = 0.0
            self.settled()
            return

        if any(body.x < -90 or body.x > WIDTH + 90 or body.y > HEIGHT + 90
               for body in self.bodies):
            self.fail()
            return
        grounded = any(max(y for _, y in body.all_vertices()) >= FLOOR_Y - 5.0
                       for body in self.bodies)
        calm = self.kinematically_calm(previous_poses)
        if grounded and calm:
            self.stable_time += dt
            if self.stable_time >= 0.80:
                if not self.tower_valid():
                    self.invalid_time += dt
                    if self.invalid_time >= 1.0:
                        self.fail()
                else:
                    self.invalid_time = 0.0
                    for body in self.bodies:
                        body.vx = 0.0
                        body.vy = 0.0
                        body.angular_velocity = 0.0
                        body.sleeping = True
                    self.settled()
        else:
            self.stable_time = 0.0
            self.invalid_time = 0.0

    def ease(self, dt):
        amount = 1.0 - math.exp(-dt / 0.03)
        self.display_x += (self.held_x - self.display_x) * amount
        self.display_angle += (self.held_angle - self.display_angle) * amount
        if abs(self.held_x - self.display_x) < 0.3:
            self.display_x = self.held_x
        if abs(self.held_angle - self.display_angle) < 0.002:
            self.display_angle = self.held_angle
        self.sway_time += dt
        for body in self.bodies:
            if body.flash:
                body.flash = max(0.0, body.flash - dt / 0.18)

    def sway(self, body):
        if self.sway_time > 1.2 or not self.sway_amount:
            return 0.0, 0.0
        height = max(0.0, min(1.0, (FLOOR_Y - body.y) / 260.0))
        envelope = self.sway_amount * math.exp(-self.sway_time / 0.16)
        dx = (self.sway_direction * 2.5 * height * envelope *
              math.sin(2.0 * math.pi * 3.2 * self.sway_time))
        dy = 2.0 * height * self.sway_amount * math.exp(-self.sway_time / 0.07)
        return dx, dy

    def update(self, dt):
        self.state_time += dt
        self.ease(dt)
        self.last_physics_steps = 0
        if 12 in self.buttons:
            self.select_held += dt
            if self.select_held >= 1.5 and self.state != "confirm_reset":
                self.request_reset_best()
        else:
            self.select_held = 0.0
        if self.state == "playing":
            accumulated = self.physics_accumulator + dt
            if accumulated > 0.10:
                self.dropped_physics_time += accumulated - 0.10
            self.physics_accumulator = min(0.10, accumulated)
            while self.physics_accumulator >= FIXED_STEP:
                self.simulate(FIXED_STEP)
                self.physics_accumulator -= FIXED_STEP
                self.last_physics_steps += 1
        elif self.state == "result" and self.state_time < FAIL_BEAT:
            self.physics_accumulator = min(0.10, self.physics_accumulator + dt)
            while self.physics_accumulator >= FIXED_STEP:
                self.simulate(FIXED_STEP)
                self.physics_accumulator -= FIXED_STEP
        elif self.state == "transition" and self.state_time >= TRANSITION_DURATION:
            self.finish_transition()


FONT = {
    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
    "B": ("11110", "10001", "10001", "11110", "10001", "10001", "11110"),
    "C": ("01111", "10000", "10000", "10000", "10000", "10000", "01111"),
    "D": ("11110", "10001", "10001", "10001", "10001", "10001", "11110"),
    "E": ("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
    "F": ("11111", "10000", "10000", "11110", "10000", "10000", "10000"),
    "G": ("01111", "10000", "10000", "10111", "10001", "10001", "01111"),
    "H": ("10001", "10001", "10001", "11111", "10001", "10001", "10001"),
    "I": ("11111", "00100", "00100", "00100", "00100", "00100", "11111"),
    "J": ("00111", "00010", "00010", "00010", "10010", "10010", "01100"),
    "K": ("10001", "10010", "10100", "11000", "10100", "10010", "10001"),
    "L": ("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
    "M": ("10001", "11011", "10101", "10101", "10001", "10001", "10001"),
    "N": ("10001", "11001", "10101", "10011", "10001", "10001", "10001"),
    "O": ("01110", "10001", "10001", "10001", "10001", "10001", "01110"),
    "P": ("11110", "10001", "10001", "11110", "10000", "10000", "10000"),
    "Q": ("01110", "10001", "10001", "10001", "10101", "10010", "01101"),
    "R": ("11110", "10001", "10001", "11110", "10100", "10010", "10001"),
    "S": ("01111", "10000", "10000", "01110", "00001", "00001", "11110"),
    "T": ("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
    "U": ("10001", "10001", "10001", "10001", "10001", "10001", "01110"),
    "V": ("10001", "10001", "10001", "10001", "10001", "01010", "00100"),
    "W": ("10001", "10001", "10001", "10101", "10101", "11011", "10001"),
    "X": ("10001", "10001", "01010", "00100", "01010", "10001", "10001"),
    "Y": ("10001", "10001", "01010", "00100", "00100", "00100", "00100"),
    "Z": ("11111", "00001", "00010", "00100", "01000", "10000", "11111"),
    "0": ("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
    "1": ("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
    "2": ("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
    "3": ("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
    "4": ("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
    "5": ("11111", "10000", "10000", "11110", "00001", "00001", "11110"),
    "6": ("01110", "10000", "10000", "11110", "10001", "10001", "01110"),
    "7": ("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
    "8": ("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
    "9": ("01110", "10001", "10001", "01111", "00001", "00001", "01110"),
    "?": ("01110", "10001", "00001", "00010", "00100", "00000", "00100"),
    "+": ("00000", "00100", "00100", "11111", "00100", "00100", "00000"),
    "<": ("00010", "00100", "01000", "10000", "01000", "00100", "00010"),
    ">": ("01000", "00100", "00010", "00001", "00010", "00100", "01000"),
}


class SDLRect(ctypes.Structure):
    _fields_ = (("x", ctypes.c_int), ("y", ctypes.c_int),
                ("w", ctypes.c_int), ("h", ctypes.c_int))


class SDLKeysym(ctypes.Structure):
    _fields_ = (("scancode", ctypes.c_int), ("sym", ctypes.c_int),
                ("mod", ctypes.c_uint16), ("unused", ctypes.c_uint32))


class SDLKeyboardEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("window_id", ctypes.c_uint32), ("state", ctypes.c_uint8),
                ("repeat", ctypes.c_uint8), ("padding2", ctypes.c_uint8),
                ("padding3", ctypes.c_uint8), ("keysym", SDLKeysym))


class SDLJoyAxisEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("which", ctypes.c_int32), ("axis", ctypes.c_uint8),
                ("padding1", ctypes.c_uint8), ("padding2", ctypes.c_uint8),
                ("padding3", ctypes.c_uint8), ("value", ctypes.c_int16),
                ("padding4", ctypes.c_uint16))


class SDLJoyButtonEvent(ctypes.Structure):
    _fields_ = (("type", ctypes.c_uint32), ("timestamp", ctypes.c_uint32),
                ("which", ctypes.c_int32), ("button", ctypes.c_uint8),
                ("state", ctypes.c_uint8), ("padding1", ctypes.c_uint8),
                ("padding2", ctypes.c_uint8))


class SDLEvent(ctypes.Union):
    _fields_ = (("type", ctypes.c_uint32), ("key", SDLKeyboardEvent),
                ("jaxis", SDLJoyAxisEvent), ("jbutton", SDLJoyButtonEvent),
                ("padding", ctypes.c_uint8 * 56))


class SDLAudioSpec(ctypes.Structure):
    _fields_ = (("freq", ctypes.c_int), ("format", ctypes.c_uint16),
                ("channels", ctypes.c_uint8), ("silence", ctypes.c_uint8),
                ("samples", ctypes.c_uint16), ("padding", ctypes.c_uint16),
                ("size", ctypes.c_uint32), ("callback", ctypes.c_void_p),
                ("userdata", ctypes.c_void_p))


class Renderer:
    def __init__(self, profile=None):
        self.profile = Path(profile) if profile else None
        library_names = ["libSDL2-2.0.so.0", "libSDL2.so", "SDL2.dll"]
        self.sdl = None
        for name in library_names:
            try:
                self.sdl = ctypes.CDLL(name)
                break
            except OSError:
                continue
        if self.sdl is None:
            raise RuntimeError("SDL2 runtime was not found")
        self._bind()
        self.sdl.SDL_SetHint(b"SDL_RENDER_SCALE_QUALITY", b"0")
        if self.sdl.SDL_Init(0x20 | 0x200 | 0x2000) != 0:
            raise RuntimeError("SDL2 could not initialise video and joystick")
        flags = 4 if os.environ.get("STAK_WINDOWED") else 0x00001005
        self.window = self.sdl.SDL_CreateWindow(b"STAK", 0x2FFF0000, 0x2FFF0000,
                                                WIDTH, HEIGHT, flags)
        if not self.window:
            raise RuntimeError("SDL2 could not create the STAK window")
        self.software_renderer = False
        self.renderer = self.sdl.SDL_CreateRenderer(self.window, -1, 2 | 4)
        if not self.renderer:
            self.software_renderer = True
            self.renderer = self.sdl.SDL_CreateRenderer(self.window, -1, 1)
        if not self.renderer:
            raise RuntimeError("SDL2 could not create the STAK renderer")
        self.sdl.SDL_RenderSetLogicalSize(self.renderer, WIDTH, HEIGHT)
        self.controller = None
        self.joystick = None
        for index in range(self.sdl.SDL_NumJoysticks()):
            if self.sdl.SDL_IsGameController(index):
                self.controller = self.sdl.SDL_GameControllerOpen(index)
                if self.controller:
                    break
        if not self.controller and self.sdl.SDL_NumJoysticks():
            self.joystick = self.sdl.SDL_JoystickOpen(0)
        self.shape_spans = {}
        self.text_arrays = {}
        self.sound_buffers = {key: ctypes.create_string_buffer(value)
                              for key, value in sound_bank().items()}
        threading.Thread(target=self.fill_sounds, daemon=True).start()
        self.mix = b""
        self.audio = 0
        if self.sdl.SDL_InitSubSystem(0x10) == 0:
            wanted = SDLAudioSpec()
            obtained = SDLAudioSpec()
            wanted.freq = AUDIO_RATE
            wanted.format = 0x8010
            wanted.channels = AUDIO_CHANNELS
            wanted.samples = 512
            self.audio = self.sdl.SDL_OpenAudioDevice(
                None, 0, ctypes.byref(wanted), ctypes.byref(obtained), 0
            )
            if self.audio:
                self.sdl.SDL_PauseAudioDevice(self.audio, 0)
            else:
                self.log_audio_error("SDL_OpenAudioDevice")
        else:
            self.log_audio_error("SDL_InitSubSystem")

    def _bind(self):
        pointer_functions = ("SDL_CreateWindow", "SDL_CreateRenderer", "SDL_JoystickOpen",
                             "SDL_GameControllerOpen")
        for name in pointer_functions:
            getattr(self.sdl, name).restype = ctypes.c_void_p
        self.sdl.SDL_CreateWindow.argtypes = (ctypes.c_char_p, ctypes.c_int, ctypes.c_int,
                                              ctypes.c_int, ctypes.c_int, ctypes.c_uint32)
        self.sdl.SDL_CreateRenderer.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_uint32)
        self.sdl.SDL_SetHint.argtypes = (ctypes.c_char_p, ctypes.c_char_p)
        self.sdl.SDL_SetHint.restype = ctypes.c_int
        self.sdl.SDL_RenderSetLogicalSize.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_int)
        self.sdl.SDL_SetRenderDrawColor.argtypes = (ctypes.c_void_p, ctypes.c_uint8,
                                                    ctypes.c_uint8, ctypes.c_uint8, ctypes.c_uint8)
        self.sdl.SDL_RenderClear.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_RenderFillRects.argtypes = (ctypes.c_void_p, ctypes.POINTER(SDLRect), ctypes.c_int)
        self.sdl.SDL_RenderDrawLine.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                                ctypes.c_int, ctypes.c_int)
        self.sdl.SDL_RenderPresent.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_PollEvent.argtypes = (ctypes.POINTER(SDLEvent),)
        self.sdl.SDL_DestroyRenderer.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_DestroyWindow.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_JoystickClose.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_GameControllerOpen.argtypes = (ctypes.c_int,)
        self.sdl.SDL_IsGameController.argtypes = (ctypes.c_int,)
        self.sdl.SDL_IsGameController.restype = ctypes.c_int
        self.sdl.SDL_GameControllerClose.argtypes = (ctypes.c_void_p,)
        self.sdl.SDL_OpenAudioDevice.restype = ctypes.c_uint32
        self.sdl.SDL_OpenAudioDevice.argtypes = (
            ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(SDLAudioSpec),
            ctypes.POINTER(SDLAudioSpec), ctypes.c_int
        )
        self.sdl.SDL_QueueAudio.argtypes = (
            ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32
        )
        self.sdl.SDL_PauseAudioDevice.argtypes = (ctypes.c_uint32, ctypes.c_int)
        self.sdl.SDL_CloseAudioDevice.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_ClearQueuedAudio.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_GetQueuedAudioSize.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_GetQueuedAudioSize.restype = ctypes.c_uint32
        self.sdl.SDL_LockAudioDevice.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_UnlockAudioDevice.argtypes = (ctypes.c_uint32,)
        self.sdl.SDL_GetError.restype = ctypes.c_char_p

    def log_audio_error(self, operation):
        if not self.profile:
            return
        error = self.sdl.SDL_GetError()
        message = error.decode("utf8", "replace") if error else "unknown SDL error"
        try:
            (self.profile / "audio_error.log").write_text(
                operation + ": " + message + "\n", encoding="utf8"
            )
        except OSError:
            pass

    def colour(self, colour):
        self.sdl.SDL_SetRenderDrawColor(self.renderer, *colour, 255)

    def clear(self):
        self.colour(BLACK)
        self.sdl.SDL_RenderClear(self.renderer)

    def rects(self, rectangles, colour):
        if not rectangles:
            return
        self.colour(colour)
        array = (SDLRect * len(rectangles))(*(SDLRect(*item) for item in rectangles))
        self.sdl.SDL_RenderFillRects(self.renderer, array, len(rectangles))

    def line(self, x1, y1, x2, y2, colour):
        self.colour(colour)
        self.sdl.SDL_RenderDrawLine(self.renderer, int(x1), int(y1), int(x2), int(y2))

    def polygon(self, points, colour):
        rows = self.scanlines(points)
        clipped = []
        for x, y, width, height in rows:
            left = max(0, x)
            right = min(WIDTH, x + width)
            if 0 <= y < HEIGHT and right > left:
                clipped.append((left, y, right - left, height))
        self.rects(clipped, colour)

    @staticmethod
    def scanlines(points):
        minimum = int(math.floor(min(y for _, y in points)))
        maximum = int(math.ceil(max(y for _, y in points)))
        rows = []
        for y in range(minimum, maximum + 1):
            intersections = []
            for index, first in enumerate(points):
                second = points[(index + 1) % len(points)]
                if (first[1] <= y < second[1]) or (second[1] <= y < first[1]):
                    amount = (y - first[1]) / (second[1] - first[1])
                    intersections.append(first[0] + amount * (second[0] - first[0]))
            intersections.sort()
            for index in range(0, len(intersections) - 1, 2):
                left = int(math.ceil(intersections[index]))
                right = int(math.floor(intersections[index + 1]))
                if right >= left:
                    rows.append((left, y, right - left + 1, 1))
        return tuple(rows)

    def piece(self, piece, x, y, angle=0.0, scale=1.0, colour=None, y_offset=0.0):
        angle_key = int(round(math.degrees(angle) / 3.0)) * 3
        scale_key = round(scale, 2)
        key = (piece.shape, piece.variant, angle_key % 360, scale_key)
        spans = self.shape_spans.get(key)
        if spans is None:
            radians = math.radians(angle_key)
            cosine, sine = math.cos(radians), math.sin(radians)
            built = []
            for polygon in piece_parts(piece):
                points = tuple((px * scale_key * cosine - py * scale_key * sine,
                                px * scale_key * sine + py * scale_key * cosine)
                               for px, py in polygon)
                built.extend(self.scanlines(points))
            spans = tuple(built)
            self.shape_spans[key] = spans
        origin_x = int(round(x))
        origin_y = int(round(y + y_offset))
        rectangles = []
        for local_x, local_y, width, height in spans:
            top = origin_y + local_y
            left = origin_x + local_x
            right = min(WIDTH, left + width)
            clipped_left = max(0, left)
            if 0 <= top < HEIGHT and right > clipped_left:
                rectangles.append((clipped_left, top, right - clipped_left, height))
        self.rects(rectangles, colour or piece.colour)

    def text(self, text, x, y, scale=2, colour=WHITE, align="left"):
        text = str(text).upper()
        cache_key = (text, int(x), int(y), int(scale), align)
        cached = self.text_arrays.get(cache_key)
        if cached is not None:
            self.colour(colour)
            self.sdl.SDL_RenderFillRects(self.renderer, cached[0], cached[1])
            return
        width = sum((6 if character != " " else 4) * scale for character in text)
        if align == "center":
            x -= width // 2
        elif align == "right":
            x -= width
        rectangles = []
        cursor = x
        for character in text:
            if character == " ":
                cursor += 4 * scale
                continue
            glyph = FONT.get(character, FONT["?"])
            for row, pattern in enumerate(glyph):
                for column, value in enumerate(pattern):
                    if value == "1":
                        rectangles.append((int(cursor + column * scale), int(y + row * scale), scale, scale))
            cursor += 6 * scale
        if not rectangles:
            return
        array = (SDLRect * len(rectangles))(*(SDLRect(*item) for item in rectangles))
        self.text_arrays[cache_key] = (array, len(rectangles))
        self.colour(colour)
        self.sdl.SDL_RenderFillRects(self.renderer, array, len(rectangles))

    def present(self):
        self.sdl.SDL_RenderPresent(self.renderer)

    def queue(self, data):
        buffer = ctypes.create_string_buffer(data)
        self.sdl.SDL_QueueAudio(self.audio, buffer, len(data))

    def fill_sounds(self):
        for sounds in later_sounds():
            for key, value in sounds.items():
                self.sound_buffers[key] = ctypes.create_string_buffer(value)

    def play_sound(self, key):
        if not self.audio:
            return
        if key not in self.sound_buffers:
            if key[0] == "impact":
                key = ("impact", min(key[1], KEYS - 1)) + key[2:]
            elif key[0] in ("complete", "best"):
                key = ("complete", 0)
        if key not in self.sound_buffers:
            return
        buffer = self.sound_buffers[key]
        data = buffer.raw[:-1]
        if key[0] in ("complete", "fail"):
            self.sdl.SDL_ClearQueuedAudio(self.audio)
            self.sdl.SDL_QueueAudio(self.audio, buffer, len(data))
            self.mix = data
            return
        self.sdl.SDL_LockAudioDevice(self.audio)
        try:
            queued = self.sdl.SDL_GetQueuedAudioSize(self.audio) & ~3
            if not queued or queued > len(self.mix):
                self.sdl.SDL_QueueAudio(self.audio, buffer, len(data))
                self.mix = data
            else:
                self.mix = mix_pcm(self.mix[-queued:], data)
                self.sdl.SDL_ClearQueuedAudio(self.audio)
                self.queue(self.mix)
        finally:
            self.sdl.SDL_UnlockAudioDevice(self.audio)

    def close(self):
        if self.audio:
            self.sdl.SDL_CloseAudioDevice(self.audio)
        if getattr(self, "controller", None):
            self.sdl.SDL_GameControllerClose(self.controller)
        if self.joystick:
            self.sdl.SDL_JoystickClose(self.joystick)
        if self.renderer:
            self.sdl.SDL_DestroyRenderer(self.renderer)
        if self.window:
            self.sdl.SDL_DestroyWindow(self.window)
        self.sdl.SDL_Quit()


def draw_piece(renderer, piece, x, y, angle=0.0, scale=1.0, colour=None, y_offset=0.0):
    renderer.piece(piece, x, y, angle, scale, colour, y_offset)


def draw_start(renderer):
    logo_top = 62
    logo_unit = 10
    for left, upper, right, lower, colour_index in LOGO_BLOCKS:
        renderer.rects(((320 + left * logo_unit, logo_top + upper * logo_unit,
                         (right - left) * logo_unit, (lower - upper) * logo_unit),),
                       FORM_PALETTE[colour_index])
    renderer.text("STAK", 320, 174, 5, WHITE, "center")
    renderer.text("D PAD", 320, 246, 2, MID, "center")
    renderer.text("CHOOSE AND MOVE", 320, 272, 2, MID, "center")
    renderer.text("L1 R1  TURN", 320, 304, 2, MID, "center")
    renderer.text("A  DROP", 320, 336, 2, MID, "center")
    renderer.text("PRESS A", 320, 418, 2, WHITE, "center")


def blend(colour, target, amount):
    return tuple(int(channel + (other - channel) * amount)
                 for channel, other in zip(colour, target))


def transition_sink(game):
    if game.state_time <= 1.35:
        return 0.0, 0.0
    amount = min(1.0, (game.state_time - 1.35) / 1.55)
    eased = amount * amount * (3.0 - 2.0 * amount)
    highest = min((y for body in game.bodies for _, y in body.all_vertices()),
                  default=FLOOR_Y)
    return eased * (HEIGHT + 60.0 - highest), amount


def draw_game(renderer, game):
    if game.state == "result":
        fade = smooth((game.state_time - FAIL_BEAT) / 0.5)
        if game.state_time < FAIL_BEAT:
            renderer.text(game.score, 28, 24, 3, WHITE)
            renderer.text(game.best, WIDTH - 28, 24, 3, WHITE, "right")
        renderer.line(28, FLOOR_Y, WIDTH - 28, FLOOR_Y, blend(MID, DIM, fade))
        for body in game.bodies:
            draw_piece(renderer, body.piece, body.x, body.y, body.angle,
                       colour=blend(body.piece.colour, FADED, fade))
        return
    renderer.text(game.score, 28, 24, 3, WHITE)
    renderer.text(game.best, WIDTH - 28, 24, 3, WHITE, "right")
    renderer.line(28, FLOOR_Y, WIDTH - 28, FLOOR_Y, MID)

    transition_offset = 0.0
    brighten = 0.0
    if game.state == "transition":
        if game.state_time > 1.0:
            brighten = min(1.0, (game.state_time - 1.0) / 0.35)
        if game.state_time > 1.35:
            transition_offset, amount = transition_sink(game)
            floor_level = int(145 - 105 * amount)
            renderer.line(28, FLOOR_Y, WIDTH - 28, FLOOR_Y,
                          (floor_level, floor_level, floor_level))
    for body in game.bodies:
        light = max(brighten, body.flash * 0.45)
        dx, dy = game.sway(body)
        draw_piece(renderer, body.piece, body.x + dx, body.y, body.angle,
                   colour=blend(body.piece.colour, WHITE, light),
                   y_offset=transition_offset + dy)

    if game.state == "playing" and game.ready_for_piece():
        piece = game.selected_piece()
        draw_piece(renderer, piece, game.display_x, SPAWN_Y, game.display_angle)
        for index, queued in enumerate(game.queue):
            draw_piece(renderer, queued, 280 + index * 40, 28, 0.0, 0.28,
                       queued.colour if index == game.queue_index else DIM)
        renderer.line(269 + game.queue_index * 40, 50,
                      291 + game.queue_index * 40, 50, WHITE)


def draw_overlay(renderer, game):
    if game.state == "result" and game.state_time >= FAIL_BEAT:
        renderer.text(game.score, 320, 142, 8, WHITE, "center")
        renderer.text("NEW" if game.new_best else "BEST", 320, 246, 2, MID, "center")
        renderer.text(game.best, 320, 274, 3, WHITE, "center")
        renderer.text("AGAIN", 320, 374, 3, WHITE, "center")
    elif game.state in ("confirm_restart", "confirm_reset"):
        renderer.rects(((0, 0, WIDTH, HEIGHT),), BLACK)
        title = "RESTART?" if game.state == "confirm_restart" else "RESET BEST?"
        renderer.text(title, 320, 188, 4, WHITE, "center")
        renderer.text("A  YES", 320, 278, 2, MID, "center")
        renderer.text("B  NO", 320, 310, 2, MID, "center")


def handle_button(game, button, down, allow_exit_combo=True):
    if down:
        game.buttons.add(button)
        if allow_exit_combo and 12 in game.buttons and 13 in game.buttons:
            game.running = False
            return
        if button == 1:
            game.confirm()
        elif button == 0:
            game.cancel()
        elif button == 8:
            game.choose(-1)
        elif button == 9:
            game.choose(1)
        elif button == 10:
            game.move(-1)
        elif button == 11:
            game.move(1)
        elif button == 13:
            game.request_restart()
    else:
        game.buttons.discard(button)


KEY_BUTTONS = {
    40: 1,
    44: 1,
    42: 0,
    82: 8,
    81: 9,
    80: 10,
    79: 11,
    21: 13,
    22: 12,
}

def handle_key(game, scancode, down, repeat=False):
    if scancode == 41 and down:
        game.running = False
        return
    if scancode in (29, 27):
        if down:
            game.rotate(-1 if scancode == 29 else 1)
        return
    button = KEY_BUTTONS.get(scancode)
    if button is not None and not repeat:
        handle_button(game, button, down)


CONTROLLER_BUTTONS = {
    0: 1,
    1: 0,
    4: 12,
    6: 13,
    11: 8,
    12: 9,
    13: 10,
    14: 11,
}
CONTROLLER_ROTATE = {9: -1, 10: 1}
CONTROLLER_GUIDE = 5


def handle_controller_button(game, button, down, axis_state, axis_repeat):
    if button == CONTROLLER_GUIDE:
        if down:
            game.running = False
        return
    if button in CONTROLLER_ROTATE:
        direction = CONTROLLER_ROTATE[button]
        if down:
            axis_state[2] = direction
            axis_repeat[2] = 0.22
            game.rotate(direction)
        elif axis_state[2] == direction:
            axis_state[2] = 0
        return
    internal = CONTROLLER_BUTTONS.get(button)
    if internal is not None:
        handle_button(game, internal, down)


def apply_axis(game, axis, direction):
    if axis == 0:
        game.move(direction)
    elif axis == 1:
        game.choose(direction)
    elif axis == 2:
        game.rotate(direction)


def axis_direction(raw_value, previous):
    if previous < 0 and raw_value < -8000:
        return -1
    if previous > 0 and raw_value > 8000:
        return 1
    if raw_value < -14000:
        return -1
    if raw_value > 14000:
        return 1
    return 0


def software_frame_delay(frame_seconds):
    return max(0, int(math.ceil((FIXED_STEP - frame_seconds) * 1000.0)))


def run(profile):
    game = Game(profile)
    renderer = Renderer(profile)
    event = SDLEvent()
    previous = time.monotonic()
    axis_state = {0: 0, 1: 0, 2: 0}
    axis_repeat = {0: 0.0, 1: 0.0, 2: 0.0}
    timing_enabled = os.environ.get("STAK_TIMING") == "1"
    timing_frames = 0
    timing_physics = 0.0
    timing_render = 0.0
    timing_late = 0
    opening_tone_pending = True
    try:
        while game.running:
            frame_started = time.perf_counter()
            now = time.monotonic()
            elapsed = min(0.05, now - previous)
            previous = now
            while renderer.sdl.SDL_PollEvent(ctypes.byref(event)):
                if event.type == 0x100:
                    game.running = False
                elif event.type in (0x300, 0x301):
                    handle_key(game, event.key.keysym.scancode,
                               event.type == 0x300, bool(event.key.repeat))
                elif renderer.controller and event.type in (0x651, 0x652):
                    handle_controller_button(game, event.jbutton.button,
                                             event.type == 0x651, axis_state, axis_repeat)
                elif renderer.controller and event.type == 0x650:
                    if event.jaxis.axis in axis_state:
                        axis = event.jaxis.axis
                        value = axis_direction(event.jaxis.value, axis_state[axis])
                        if value != axis_state[axis]:
                            axis_state[axis] = value
                            axis_repeat[axis] = 0.22
                            if value:
                                apply_axis(game, axis, value)
                elif renderer.controller:
                    pass
                elif event.type in (0x603, 0x604):
                    if event.jbutton.button not in (4, 5):
                        handle_button(game, event.jbutton.button, event.type == 0x603)
                elif event.type == 0x600 and event.jaxis.axis in axis_state:
                    axis = event.jaxis.axis
                    value = axis_direction(event.jaxis.value, axis_state[axis])
                    if value != axis_state[axis]:
                        axis_state[axis] = value
                        axis_repeat[axis] = 0.22
                        if value:
                            apply_axis(game, axis, value)
            for axis, value in axis_state.items():
                if not value:
                    continue
                axis_repeat[axis] -= elapsed
                if axis_repeat[axis] <= 0.0:
                    apply_axis(game, axis, value)
                    axis_repeat[axis] += 0.09 if axis == 0 else 0.20 if axis == 1 else 0.16
            physics_started = time.perf_counter() if timing_enabled else 0.0
            game.update(elapsed)
            if timing_enabled:
                timing_physics += time.perf_counter() - physics_started
            if game.audio_events:
                for key in game.audio_events:
                    renderer.play_sound(key)
                game.audio_events.clear()
            render_started = time.perf_counter() if timing_enabled else 0.0
            renderer.clear()
            if game.state == "start":
                draw_start(renderer)
            else:
                draw_game(renderer, game)
                draw_overlay(renderer, game)
            renderer.present()
            if opening_tone_pending:
                renderer.play_sound(("complete", 0))
                opening_tone_pending = False
            if timing_enabled:
                timing_render += time.perf_counter() - render_started
                timing_frames += 1
                if time.perf_counter() - frame_started > FIXED_STEP * 1.25:
                    timing_late += 1
                if timing_frames == 300:
                    try:
                        with (Path(profile) / "timing.log").open("a", encoding="ascii") as log:
                            log.write(
                                "physics_ms={:.3f} render_ms={:.3f} late={} dropped={:.3f}\n".format(
                                    timing_physics * 1000.0 / timing_frames,
                                    timing_render * 1000.0 / timing_frames,
                                    timing_late, game.dropped_physics_time,
                                )
                            )
                    except OSError:
                        pass
                    timing_frames = 0
                    timing_physics = 0.0
                    timing_render = 0.0
                    timing_late = 0
            if renderer.software_renderer:
                delay = software_frame_delay(time.perf_counter() - frame_started)
                if delay:
                    renderer.sdl.SDL_Delay(delay)
            else:
                renderer.sdl.SDL_Delay(1)
    finally:
        renderer.close()


def main():
    profile = sys.argv[1] if len(sys.argv) > 1 else str(Path.home() / ".stak")
    run(profile)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
