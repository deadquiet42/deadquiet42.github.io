STAK
LINUX / 2026

LEFT / RIGHT    MOVE
UP / DOWN       CHOOSE
Z / X           ROTATE
SPACE           DROP / BEGIN
R               RESTART
HOLD DELETE     RESET BEST
ESC             EXIT

Controller input is supported through SDL2.

Requires a 64 bit glibc Linux desktop with normal X11 or Wayland graphics
and desktop audio libraries. Python and SDL2 are included.

deadquiet42
small software objects
